#include "semigroups_cpp.h"
#include <Python.h>

namespace libsemigroups {};
