#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Tue Mar  7 14:55:20 2017

@author: cmr1
"""

import networkx as nx

# Question 1

def IsUnfriendly(G, L):
    if len(set(L))!= len(L): # make sure all entries are distinct
        return False
    # Check have a list of vertices of G
    verts = G.nodes()
    for x in L:
        if not x in verts:
            return False
    # Now check we have an unfriendly set
    e = G.edges()
    for x in e:
        if (x[0] in L) and (x[1] in L):
            return False
    return True

# Question 2

def IskUnfriendly(G,k,L):
    # Check L is a list of k distinct elements
    if len(set(L))!= k:
        return False
    # now check they form an unfriendly set
    return IsUnfriendly(G, L)

# Question 3


def kUnfriendlyExtending(G, k, L):
    assert isinstance(L, list)
    if not IsUnfriendly(G, L): # L contains two adjacent vertices,
                               # so can't be grown to an unfriendly set. 
        return False, []
    if IskUnfriendly(G, k, L): # found a solution
        return True, L
    verts = G.nodes()
    for vertex in verts:
        b, L1 = kUnfriendlyExtending(G, k, L+[vertex])
        if b:
            return True, L1
    return False, []
        


# The following function does the same thing, but is more efficient.
# We only add vertices to L that come later in the list of nodes
# than the ones that are already there. That means that we only consider 
# each possible set of nodes once

def MoreEfficientkUnfriendlyExtending(G, k, L):
    assert isinstance(L, list)
    if not IsUnfriendly(G, L): # L contains two adjacent vertices,
                               # so can't be grown to an unfriendly set. 
        return False, []
    if IskUnfriendly(G, k, L): # found a solution
        return True, L
    verts = G.nodes()
    n = len(verts)
    verts.sort()  # These next 6 lines are for efficiency. We find the lowest
             # numbered vertex that's not in L, and only test adding vertices
             # from there. This means we don't encounter the same list
             # more than once
    L.sort() 
    if len(L) == 0: 
        last = -1
    else:
        last = verts.index(L[-1])
    for i in range(last+1, n): 
        b, L1 = MoreEfficientkUnfriendlyExtending(G, k, L+[verts[i]])
        if b:
            return True, L1
    return False, []
        


# Question 4

G = nx.erdos_renyi_graph(25, 0.4, seed=20)

b, l = kUnfriendlyExtending(G, 7, [])  # start with an empty list as we 
                                       # don't know what vertices should be in it
# b is true, l = [5, 6, 10, 13, 15, 17, 20]
    
b2, l2 = MoreEfficientkUnfriendlyExtending(G, 7, []) 
# b2 is true, l2 is [5, 6, 10, 13, 15, 17, 20]