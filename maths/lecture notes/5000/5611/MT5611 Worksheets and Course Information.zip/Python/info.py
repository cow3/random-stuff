# Code in Worksheet o - Version 1.0

import os
d = os.path.dirname(__file__)

# Problem 0
def this_is_only_an_example_do_not_really_do_it(x, y, z, t):
    for i in xrange(1000000):
        pass
    return "Wee Willie Winkie: " + str(x + y + z + t)

# part (a)
this_is_only_an_example_do_not_really_do_it(1,2,3,4)
# returns "Wee Willie Winkie: 10"

# part (b)
this_is_only_an_example_do_not_really_do_it(1,5,3,0)
# returns "Wee Willie Winkie: 9"

f = file("/Users/jdm/Desktop/mt2505/cayley-tables-3.p", "rb")

import os
dir = os.path.dirname(__file__)

f = file(dir + "/cayley-tables-3.p", "rb")

import math

# Problem 1

# A function to find the primes less than the integer n.
#
# This is a translation of the pseudocode from wikipedia:
# https://en.wikipedia.org/wiki/Sieve_of_Eratosthenes
def primes(n):
    A = [True for x in xrange(n)]
    for i in xrange(2, int(math.sqrt(n)) + 1):
        if A[i]:
            for j in xrange(i ** 2, n, i):
                A[j] = False
    B = []
    for i in xrange(2, n):
        if A[i]:
            B.append(i)
    return B

sum(primes(2000000))
# returns 142913828922

