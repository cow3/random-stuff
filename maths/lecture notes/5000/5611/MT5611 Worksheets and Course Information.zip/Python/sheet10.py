#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Tue Feb 21 11:24:38 2017

@author: colva
"""

import networkx as nx

g = nx.Graph()
for i in range(6):
    g.add_node(i)
for i in range(1,6):
    g.add_edge(0,i)
g.add_edge(1,2)
g.add_edge(2,3)
g.add_edge(3,4)
g.add_edge(4,5)
g.add_edge(1,5)    

import pylab as pyl

nx.draw(g)
pyl.show()

nx.draw(g, with_labels=True)
pyl.show()

nx.draw_random(g, with_labels=True)
pyl.show()

nx.draw_circular(g, with_labels=True)
pyl.show()

n = g.nodes()
# n is now [0, 1, 2, 3, 4, 5]
e = g.edges()
# e is now  [(0, 1), (0, 2), (0, 3), (0, 4), (0, 5), (1, 2),
# (1, 5), (2, 3), (3, 4), (4, 5)]

node_count1 = g.number_of_nodes()
# node_count1 is now 6
edge_count1 = g.number_of_edges()
# edge_count1 is now 10

g.add_node(7)
g.add_nodes_from([10, 12])
g.remove_node(5)

g.add_edge(0,7)
g.add_edges_from([(0,10),(4,7),(7,10),(10,1)])
                 
k5 = nx.complete_graph(5)
k7 = nx.complete_graph(7)

rg = nx.erdos_renyi_graph(10, .1)
nx.draw(rg, with_labels=True)
pyl.show()


nbs = g.neighbors(2)
#nbs is now [0, 1, 3]

deg0 = g.degree(0)
#deg0 is now 6

deg_dict = g.degree()
#deg_dict is the dictionary
# {0: 6, 1: 3, 2: 3, 3: 3, 4: 3, 7: 3, 10: 3, 12: 0}

deg_dict[0]
#returns 6
deg_dict[12]
#returns 0

deg_dict.keys()
#returns [0, 1, 2, 3, 4, 7, 10, 12]
deg_dict.values()
#returns [6, 3, 3, 3, 3, 3, 3, 0]

