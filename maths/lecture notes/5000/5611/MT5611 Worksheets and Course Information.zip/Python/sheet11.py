#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Mon Feb 27 10:40:56 2017

@author: cmr1
"""

import networkx as nx
import pylab as pyl

G = nx.Graph()
for i in range(5):
    G.add_node(i)
for i in [0, 2, 3, 4]:
    G.add_edge(1,i)
for i in [0, 3, 4]:
    G.add_edge(2, i)
G.add_edge(3, 4)    

nx.draw(G)
pyl.show()

import scipy as sp
adj1 = nx.adjacency_matrix(G)
m = adj1.todense()
#matrix([[0, 1, 1, 0, 0],
#        [1, 0, 1, 1, 1],
#        [1, 1, 0, 1, 1],
#        [0, 1, 1, 0, 1],
#        [0, 1, 1, 1, 0]])