#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Wed Mar  1 11:45:52 2017

@author: cmr1
"""

import networkx as nx
import pylab as pyl

g = nx.erdos_renyi_graph(5, 0.6, seed=50)
nx.draw(g, with_labels = True)
pyl.show()

d = nx.greedy_color(g)
# d = {0: 0, 1: 1, 2: 2, 3: 0, 4: 2}