#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Sat Mar  4 17:52:35 2017

@author: cmr1
"""

import itertools as iter

vals = range(4)
m = iter.product(vals, repeat= 2)
L = []
for x in m:
    L.append(list(x))
# L = [[0, 0], [0, 1], [0, 2], [0, 3], [1, 0], [1, 1],
# [1, 2], [1, 3], [2, 0], [2, 1], [2, 2], [2, 3],
# [3, 0], [3, 1], [3, 2], [3, 3]]


L1 = []
for x in m:
   L1.append(list(x)) 
# L1 is []