# Code in Worksheet 2 - Version 1.1

x = 1

x = 1
y = 2
y / 2 == x
# returns True

x = 1
x = x + 2
x += x
x /= x
# at the end of this x has the value 1

1 == True
# returns True
2 == True
# returns False
2 == False
# returns False
2 == 2.0
# returns True
False / True == 0
# returns True
True / False == 0
# gives the error
#  Traceback (most recent call last):
#    File "<stdin>", line 1, in <module>
#  ZeroDivisionError: integer division or modulo by zero
1 == "1"
# returns False
True == "1"
# returns False

1 + "1"
# gives the error
# Traceback (most recent call last):
#   File "<stdin>", line 1, in <module>
# TypeError: unsupported operand type(s) for +: `int' and `str'

1.0 + 1
# returns 2.0
1 / 2
# returns 0
1.0 / 2.0
# returns 0.5

3141592653589793.0 / 10 ** 15 == math.pi
# returns True

10 * 0.1
# returns 1.0

x = 0.0
x += 0.1
x += 0.1
x += 0.1
x += 0.1
x += 0.1
x += 0.1
x += 0.1
x += 0.1
x += 0.1
x += 0.1
# returns 0.9999999999999999

x == 1
# returns False, maybe we got the type wrong!?
x == 1.0
# returns False, nope

if (x % 2) == 0:
    y = x / 2
else:
    y = 3 * x + 1

if 0 <= x <= 10:
    print "That is between zero and ten inclusive"
elif 10 < x < 20:
    print "That is between ten and twenty"
else:
    print "That is outside the range zero to twenty"

if x == 42:
  print "the meaning of life"
else:
   print nothing

if x == 42:
   print "the meaning of life"
else:
print 666

if str(False):
    print "wait why is this printed?"

if str(False) == True:
    print "wait why is this not printed?"

