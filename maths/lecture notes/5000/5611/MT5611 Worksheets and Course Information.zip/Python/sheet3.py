# Code in Worksheet 3 - Version 1.0

x = 0.0
x += 0.1
x += 0.1
x += 0.1
x += 0.1
x += 0.1
x += 0.1
x += 0.1
x += 0.1
x += 0.1
x += 0.1

x = 0.0
for var in range(10):
    x += 0.1

range(10)
# returns [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]

x = 0.0
for var in range(10):
    x += 0.1
    print "var =", var, "and x =", x
# Prints
# var = 0 and x = 0.1
# var = 1 and x = 0.2
# var = 2 and x = 0.3
# var = 3 and x = 0.4
# var = 4 and x = 0.5
# var = 5 and x = 0.6
# var = 6 and x = 0.7
# var = 7 and x = 0.8
# var = 8 and x = 0.9
# var = 9 and x = 1.0

for var in xrange(3, 12, 4):
    print var

print "bananas"
# Prints
# 3
# 7
# 11
# bananas

total = 0
for var in xrange(a, n, d):
    total += var

total  
# returns the sum of the first n terms

total = 0.0
for var in xrange(1, 100000):
    total += 1.0 / var

total  
# returns 12.090136129863335

total = 0.0
for var in xrange(1, 100000, 1):
    total += (1.0 / var ** 2)

total  
# returns 1.6449240667982423
(math.pi ** 2) / 6
# returns 1.6449340668482264, snap!

total = 0.0
n = 1.0
while total < 13:
    total += 1.0 / n
    n += 1

n
# returns 248398.0, and that's some slow growth

listymclistface = ["a", 2]

listymclistface[0]
# returns "a"
listymclistface[1]
# returns 2

listymclistface[-1]
# returns 2
listymclistface[-2]
# returns "a"

listymclistface[3]
# Gives an error:
# Traceback (most recent call last):
#   File "<stdin>", line 1, in <module>
# IndexError: list index out of range

listymclistface.append(False)
listymclistface
# returns ['a', 2, False]
listymclistface.append(['b', 3, True])
listymclistface
# returns ['a', 2, False, ['b', 3, True]]

listymclistface.extend([10, 11, 12, 14])
# returns ['a', 2, False, ['b', 3, True], 10, 11, 12, 14]

listymclistface[3:7]
# [['b', 3, True], 10, 11, 12]
listymclistface[4:]
# returns the elements from position 4 to the end of list
# returns [10, 11, 12, 14]
listymclistface[:3]
# returns the elements from the beginning of the list to position 3
# returns ['a', 2, False]
listymclistface[::2]
# returns every other element
# ['a', False, 10, 12]
listymclistface[3::2]
# returns every other element starting from position 3
# returns [['b', 3, True], 11, 14]

"saskfhgjahhlkjaklfjHello, world"[19:]
# returns 'Hello, world'

for x from 1 to 10:
   x = x + 1
    print x

