# Code in Worksheet 4 - Version 1.0

def my_first_function():
    print "hello, world!"

my_first_function()
# prints "hello, world!"

def sum_squares(n):
    '''This function returns the sum of the squares of 1, ..., n.'''
    # This string describes what the function does
    assert isinstance(n, int)   # Check n is an integer
    sum = 0                     # Initialise the value we will return
    for i in xrange(1, n + 1):  # Loop over the numbers 1 to n 
        sum += i ** 2           # Add i square to the total sum
    return sum                  # Return the sum value

# Tests
sum_squares(5)
# returns 55
# Let's just double check that this is correct
1 + 2 ** 2 + 3 ** 2 + 4 ** 2 + 5 ** 2
# returns 55
# It works (at least for the number 5)

# Some more tests . . .
sum_squares(10)
# returns 385
sum_squares(100)
# returns 338350

# Some incorrect input . . .
sum_squares("a")
# gives an AssertionError
sum_squares([1,2,3])
# gives an AssertionError

# Test some corner cases . . .
sum_squares(-1)
# returns 0
sum_squares(-100)
# returns 0
sum_squares(1)
# returns 1
sum_squares(0)
# returns 0

assert isinstance(n, int)

assert condition

isinstance(n, int)  # Check the variable n is an integer
isinstance(10, int) 
# returns True
isinstance(-1113, int) 
# returns True
isinstance(1.0, int) 
# returns False

isinstance(n, str)  # Check the variable n is a string
isinstance("aksjdaj", str) 
# returns True
isinstance('asjdakj', str) 
# returns True
isinstance(1.0, str) 
# returns False

isinstance(n, bool) # Check the variable n is a boolean value
isinstance("aksjdaj", bool) 
# returns False
isinstance(True, bool) 
# returns True
isinstance(False, bool) 
# returns True
isinstance(1.0, bool) 
# returns False

# Check if the variable n is a float, and strictly bigger than 0
assert isinstance(n, float) and n > 0

# Check if the variable n is an integer, and not equal to 0
assert isinstance(n, int) and n != 0

# Check if the variable n is a integer, or a float
assert isinstance(n, int) or isinstance(n, float)

def squareit(n):
    return n ** 2

map(squareit, xrange(6))
# returns [0, 1, 4, 9, 16, 25]

map(lambda x: x ** 2, xrange(6))
# returns [0, 1, 4, 9, 16, 25]

foo = lambda x, y: x * y
foo(2, 3);
# returns 6
foo(100, 101)
# returns 10100

def fold_left(lst, func, init):
    assert isinstance(lst, list) and callable(func)
    acc = init;
    for x in lst:
        acc = func(acc, x);
    return acc

lst = [-12, 5, -72, -18, 92]
fold_left(lst, lambda x, y: x + y, 0)
# returns -5

i = 1
def f(n):
    total = 0
    for i in xrange(1, 11):
        total + i
    return total

f(10)
i

def add_n(n):
    def foo(x):
        return x + n
    return foo

myfunc = add_n(100) 
myfunc(4)
# returns 104

def new_counter():
    c = [0]
    def counter(): 
        c[0] += 1
        return c[0]
    return counter

def newer_counter():
    c = 0
    def counter(): 
        c += 1
        return c
    return counter

