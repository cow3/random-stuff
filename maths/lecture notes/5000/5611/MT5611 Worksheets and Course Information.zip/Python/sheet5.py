# Code in Worksheet 5 - Version 1.0

from numpy import arange, cos    # import things from numpy
import matplotlib.pyplot as plt  # import pyplot and use short name plt
x = arange(-5., 5., 0.1)         # floats from -5. to 5. in steps of 0.1
plt.plot(x, cos(x))              # plot the values in x against those in cos(x) 
plt.show()                       # display the plot (opens a new window) 

x = arange(0.,1.,0.1)
cos(x)
# array([ 1.        ,  0.99500417,  0.98006658,  0.95533649,  0.92106099,
#         0.87758256,  0.82533561,  0.76484219,  0.69670671,  0.62160997])

plt.plot(x, cos(x))
# Returns [<matplotlib.lines.Line2D object at 0x1107c45d0>]

x = arange(-5., 5., .1)                  # Floats from -5. to 5. in steps of .1
plt.plot(x, cos(x))                      # Same plot as last time
plt.xlabel("The horizontal axis")        # Label for the x-axis
plt.ylabel("The vertical axis")          # Label for the y-axis
plt.title("A more complicated example")  # Title for the plot
plt.axis([-10, 10, -1.5, 1.5])           # Axis [xmin, xmax, ymin, ymax] 
plt.text(0, 1.3, "here is some text")    # A note at (0, 1.3)
plt.annotate("a point on curve",         # An arrow pointing at the curve
             xy=(0, 1),
             xytext=(2 , 0.75),
             arrowprops=dict(arrowstyle="->"))
plt.show()

x = arange(-.15, .15, 0.0001)                  
plt.plot(x, x * sin(1/x), label="x sin(1/x)")
plt.plot(x, x, "r--", label="y=x")
plt.plot(x, -x, "r--", label="y=-x")
plt.plot(x, x * x, "gx", label="y=x ^ 2")
plt.axis([-0.2, 0.2, -0.15, 0.15])
plt.grid(True)
plt.title("The topologist's sine curve")
plt.legend(loc="lower center")
plt.show()

import random
y = map(lambda x: random.choice(range(10000)), range(10))
bars = plt.bar(range(10), y, 1, align='center')
plt.xticks(range(10))
plt.axis([-0.5, 9.5, 0, 12000])
for i in xrange(0, 10, 3):
    bars[i].set_color('r')

for i in xrange(1, 10, 3):
    bars[i].set_color('g')

from random import uniform
data = map(lambda x: uniform(2.0, 3.0), xrange(430))
data.extend(map(lambda x: uniform(1.0, 2.0), xrange(210)))
data.extend(map(lambda x: uniform(0.0, 1.0), xrange(80)))
data.extend(map(lambda x: uniform(-1., .0), xrange(60)))
random.shuffle(data)
plt.hist(data, arange(-1., 3., 0.2), color="red")
plt.show()

data = map(lambda x: benchmark(not_so_fast, x, 10), xrange(1, 20, 1))
x = arange(1, 20, 1)
plt.plot(x, data, 'gx')
plt.plot(x, x, 'r--')
plt.plot(x, x ** 2, 'r--')
plt.plot(x, x ** 3, 'r--')

theta = np.arange(-2 * np.pi, 2 * np.pi, 0.01)
r = 2 * (1 + np.cos(theta))
plt.plot(r, theta)
plt.show()

n = 1024
X = np.random.normal(0, 1, n)
Y = np.random.normal(0, 1, n)

plt.scatter(X, Y)

