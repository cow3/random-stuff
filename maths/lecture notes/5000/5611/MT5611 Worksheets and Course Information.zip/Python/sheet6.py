# Code in Worksheet 6 - Version 1.0

import time

def super_fast(n):
    'Returns n after waiting for n milliseconds'
    assert isinstance(n, int) and n > 0
    time.sleep(float(n) / 1000) # Wait for n milliseconds
    return n

start = time.time()                       # Start timing
super_fast(10)                            # Run the function
end = time.time()                         # Stop timing
print int((end - start) * 1000), "ms"     # Print the number of milliseconds 

def benchmark(func, arg, trials = 1):
    '''
    Returns a list of floats (of length trials) indicating the time taken in
    milliseconds to run func(arg).
    '''
    result = []                               # The list of times
    for n in xrange(trials):                  
        start = time.time()                   # Measure the time taken to 
        func(arg)                             # by func(arg)
        end = time.time()
        result.append((end - start) * 1000)   # Convert to milliseconds
    return result

import matplotlib.pyplot as plt
data = benchmark(super_fast, 10, 100)
plt.hist(data, arange(10.0, 13.0, 0.1), color="red")
plt.xticks(arange(10.0, 13.5, 0.5))
plt.show()

def mean_time(func, arg, trials = 1):
    return sum(benchmark(func, arg, trials)) / trials

X = xrange(1, 100, 1)
Y = map(lambda x: benchmark(super_fast, x, 10), X)
plt.plot(X, Y, 'gx')
plt.plot(X, X, 'r-', linewidth=2)

def not_so_fast(n):
    'Returns n after waiting for n ** 3 milliseconds'
    assert isinstance(n, int) and n > 0
    time.sleep(float(n ** 3) / 1000)
    return n

data = map(lambda x: benchmark(not_so_fast, x, 10), xrange(1, 20, 1))
x = arange(1, 20, 1)
plt.plot(x, data, 'gx')
plt.plot(x, x, 'r--')
plt.plot(x, x ** 2, 'r--')
plt.plot(x, x ** 3, 'r--')

a = [1, 2, 3]
b = a
b[1] = 23       # Modifying b . . .
a               # . . . also modifies a
a is b          # . . . because they refer to the same object
a == b          # Returns True
b = [1, 23, 3]  
a == b          # Returns True
a is b          # Returns False

# It doesn't work this way with all objects
a = 1 
b = a
a is b          # Returns True
a += 1
b               # Returns 1

a = [1, 2, 3]
b = a[:]        # Copy a using a slice
b[1] = 23       # Modifying b . . .
a               # . . . does not modify a
a is b          # . . . because they do not refer to the same object

data = []
X = xrange(10 ** 3, 10 ** 5, 100)
for n in X:
    listy = range(1, n + 1)
    data.append(mean_time(lambda l: l[:], listy, 10))

plt.plot(X, data, 'gx')
plt.xlabel('Length of list n')
plt.ylabel('Time in milliseconds')
plt.title('Time to copy a list')
plt.show()

count = [0]
def count_and_ret(x):
    count[0] += 1
    return x

for x in [True, False]:
    for y in [True, False]:
        z = count_and_ret(x) or count_and_ret(y);
        print x, "or", y, "=", z

count

def is_even(n):
    assert isinstance(n, int)
    return (n % 2) == 0

def is_perfect(n):
    '''An integer is perfect if it is the sum of its proper divisors.'''
    assert isinstance(n, int)
    return n == sum(divisors(n)) - 1 - n # https://goo.gl/Qzrhmb
   
def count_even_perfect1(n):
    listy = xrange(1, n)
    return reduce(lambda nr, n: nr + is_perfect(n) and is_even(n), listy, 0)

mean_time(count_even_perfect1, 10 ** 4)
# Returns 620.2 (milliseconds)

def count_even_perfect2(n):
    listy = xrange(1, n)
    return reduce(lambda nr, n: nr + is_even(n) and is_perfect(n), listy, 0)

mean_time(count_even_perfect2, 10 ** 4)
# Returns 389.3 (milliseconds)


foo1 = lambda L: sum(L)

def foo2(L):
    result = 0
    for x in L:
        result += x
    return result

def foo3(L):
    result = 0
    for i in xrange(len(L)):
        result = result + L[i]
    return result

def foo4(L):
    result = 0
    for i in range(len(L)):
        result = result + L[i]
    return result

def foo5(L):
    result = 0
    i = 1
    while i < len(L):
        result = result + L[i]
        i = i + 1
    return result

import math
def primes(n):
    '''Returns a list of the primes less than n. This is a translation of the
      pseudocode from wikipedia:
      https://en.wikipedia.org/wiki/Sieve_of_Eratosthenes'''
    assert isinstance(n, int)
    A = [True for x in xrange(n)]
    for i in xrange(2, int(math.sqrt(n)) + 1):
        if A[i]:
            for j in xrange(i ** 2, n, i):
                A[j] = False
    return [p for p in xrange(2, n) if A[p]]

