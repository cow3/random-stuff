# Code in Worksheet 7

import random

random.seed(0)

random.randrange(100)
# returns 84

list= []
for i in xrange(1,10):
    list.append(random.randrange(20))
# list is now [15, 8, 5, 10, 8, 15, 6, 9, 11]

things = ["blob", 2, 4.9, "a"]
random.choice(things)
# returns 'a'

def MyShuffle(n):
    result = []
    startList= range(1, n+1)
    for i in range(n):
        x = random.choice(startList)
        result.append(x)
        startList.remove(x)
    return result
    
MyShuffle(5)
# returns [3, 2, 5, 4, 1]

MyShuffle(5)
# returns [5, 4, 3, 2, 1]

MyShuffle(5)
# returns [4, 5, 3, 1, 2]

MyShuffle(0)
# returns []  
 
    
 
def RecShuffle(L):
    n = len(L)
    if n < 2:
        return L 
    res = RecShuffle(L[:-1])
    split = random.randrange(n)
    return  res[:split] + [L[-1]] + res[split:]

RecShuffle([1, 2, 3, 4, 5])
# returns [2, 3, 1, 4, 5]

def BubbleSort(L):
    n = len(L)
    for i in range(n):
        for j in range(n-i-1):
            if L[j] > L[j+1]:
                z = L[j]
                L[j] = L[j+1]
                L[j+1] = z
    return L
    
a = MyShuffle(5)
# makes a = [3, 5, 1, 4, 2]    
BubbleSort(a)
# returns [1, 2, 3, 4, 5]
a    
# returns [1, 2, 3, 4, 5]
 
import copy as copy
 
def CopyBubbleSort(L):
    n = len(L)
    answer = copy.copy(L)
    for i in range(n):
        for j in range(n-i-1):
            if answer[j] > answer[j+1]:
                z = answer[j]
                answer[j] = answer[j+1]
                answer[j+1] = z
    return answer
  
a = MyShuffle(5)
# makes a = [1, 4, 3, 5, 2]
CopyBubbleSort(a)
# returns [1, 2, 3, 4, 5]
a    
# returns [1, 4, 3, 5, 2]                
    
