#code in Worksheet 8

L = [1, 3, 7, 9, 11, 13, 14]
a = 8
L = L[:3] + [a] + L[3:]
# L is now [1, 3, 7, 8, 9, 11, 13, 14]

a = 10
n = len(L)
i = 0
while (i < n) and (L[i] < a):
    i = i+1
# now i = 5 
   

a = 12
L = [1, 4, 5, 6, 8, 10, 13, 14]
left = 0
right = len(L) - 1
while ((right - left) > 1):
    m = int((left + right)/2)
    if (L[m] < a):
        left = m
    else:
        right = m
# now left = 5 and right = 6    