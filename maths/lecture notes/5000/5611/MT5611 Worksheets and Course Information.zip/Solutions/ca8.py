# little utility functions
def letter_inv(l):
    return l.swapcase()
    
def push(l,x):
    l.append(x)
    return x
    
def pop(l):
    return l.pop()
    
def top(l):
    if len(l) == 0:
        return None,False
    else:
        return l[-1],True
        
def empty(w):
    return w == ''

# Q1
def reduce(w):
    if empty(w):
        return w
    else:
        stack = []
        for x in w:
            y,e = top(stack)
            if e and y == letter_inv(x):
                pop(stack)
            else:
                push(stack,x)
        return ''.join(stack)
        
# Q2
def equivalent(v,w):
    return reduce(v) == reduce(w)
    
# this uses reduce() twice, plus an O(len(v) + len(w)) string 
# comparison.  since reduce reads each letter of its input
# once, and does O(1) work for each letter, it is linear
# time.  thus, the whole thing is linear time
    
# Q3
def cyclic_reduce(w):
    w = reduce(w)
    if empty(w):
        return w
    else:
        i = 0
        
        while w[i] == letter_inv(w[-i-1]):
            i = i + 1
            
        if i == 0:
            return w
        else:
            return w[i:-i]
# Q4
def conjugate(v,w):
    return min_rotation(cyclic_reduce(v)) == min_rotation(cyclic_reduce(w))
    
# we have as given that min_rotation is linear time, so if cyclic_reduce
# is, so is conjugate, by similar reasoning to above.  cyclic_reduce 
# is linear time, since it is a call to O(n) reduce, followed by 
# reading the reduced word one time and perhaps copying it.
# (it is easy to see that letter_inv is constant-time)

# min_rotation()

def run_extend_from(w,x,i):
    """
    w is the string were are reading
    x is a Lyndon word
    i is where to start reading
    
    return the word we found as the first value
    
    the second value is:
    
    0 if we found a copy of x
    1 if we found a Lyndon word bigger than x
    2 otherwise 
    """
    n = len(w)
    m = len(x)
    j = i
    k = 0
    
    while j < n and k < m and w[j] == x[k]:
        j = j + 1
        k = k + 1
    
    if j == n and k < m:
        # fell of the end of w with a prefix of x
        # this is always case 2
        return 'junk', 2
    
    if k == m:
        # found a copy of x
        return w[i:j], 0
    elif w[j] > x[k]:
        # found a Lyndon word bigger than x
        # greedily extend and return
        j = j + 1
        while j < n and w[j] > w[j-1]:
            j = j + 1
            
        return w[i:j],1
    else:
        return 'junk',2
            

def initial_factors(w,k=0):
    """
    Returns a list of the leading CFL factors of 
    w and the place to continue reading (as the 
    2nd value)
    
    k is where to start reading from
    """
    n = len(w)
    i = k + 1
    run = [ w[k] ]
    
    while True:
        x,stat = run_extend_from(w,run[0],i)
        
        if stat == 2:
            # the current run consists of CFL factors
            return run, len(run)*len(run[0])
        elif stat == 1:
            # the current run collapses
            run = [''.join(run) + x]
            i = i + len(x)
        else:
            # extend the current run
            run.append(x)
            i = i + len(x)
        
        assert i <= n
        
        if i == n:
            return run, len(run)*len(run[0])
            
def cfl(w):
    n = len(w)
    i = 0
    factors = list()
    
    while i < n:
        f,l = initial_factors(w,i)
        factors += f
        i = i + l
    
    assert i == n
    return factors
        
def convert_runs(L):
    rv = list()
    n = len(L)
    
    if n == 0:
        return L
    else:
        current = L[0]
        count = 1
        for i in range(1,n - 1):
            if L[i] == current:
                count = count + 1
            else:
                rv.append((current,count))
                current = L[i]
                count = 1
                
        if L[n - 1] == current:
            rv.append((current,count + 1))
        else:
            rv.append((current,count))
            rv.append((L[n-1],1))
            
        return rv
       
def min_rotation(w):
    n = len(w)
    factors = convert_runs(cfl(2*w))
    
    for f,l in factors:
        k = len(f)
        
        if n % k == 0 and k*l >= n:
            return (n//k) * f