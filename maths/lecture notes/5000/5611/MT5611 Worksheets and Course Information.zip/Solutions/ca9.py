import numpy as np
import networkx as nx

def zero_diagonal(A):
    np.fill_diagonal(A,0)

# this is the matrix B
def adj_square(A):
    AA = A*A
    AA += A
    AA[AA>0] = 1
    zero_diagonal(AA)
    return AA
    
def nnz(A):
    return np.count_nonzero(A)
    
def is_complete(A):
    n,_ = A.shape
    # the diagonal is all zeros
    return nnz(A) == n*(n-1)

# compute the degrees as a row vector by summing
# the columns of the adjacency matrix
def degrees(A):
    return np.sum(A,0)

# return a matrix each column j the degree
# of vertex j repeated n times
def degmat(A):
    n,_ = A.shape
    return np.tile(degrees(A),(n,1))

# np.multiply is the Hadamard product
def hada(A,B):
    return np.multiply(A,B)

# this is the matrix P.  notice that
# we compute Y by a Hadamard product
def parity_matrix(A,DAA):
    Z = np.zeros_like(DAA)
    Z[DAA*A < hada(degmat(A),DAA)] = 1
    return Z

# the algorithm as given
def APSP(A):
    if is_complete(A):
        return A
    else:
        AA = adj_square(A)
        DAA = APSP(AA)
        return 2*DAA - parity_matrix(A,DAA)

# this is safe on 0/1 matrices of floats, not
# in general
def mat_eq(A,B):
    return np.all(A==B)
    
# modification for disconnected graphs
def APSP2(A):
    AA = adj_square(A)
    if mat_eq(A,AA):
        return A
    else:
        DAA = APSP2(AA)
        return 2*DAA - parity_matrix(A,DAA)
        
# timing
from functools import wraps
from time import time

def timed(f):
    @wraps(f)
    def wrap(*args, **kw):
        ts = time()
        result = f(*args, **kw)
        te = time()

        return result,te - ts
    return wrap
    
# for testing

@timed
def tfw(G):
    return nx.floyd_warshall_numpy(G)
    
@timed
def tseidel(A):
    return APSP(A)
    
# some examples
''''
>>> from ca9 import *
>>> G1k = nx.erdos_renyi_graph(1000,0.01)
>>> G2k = nx.erdos_renyi_graph(2000,0.01)
>>> x = [tseidel(nx.adjacency_matrix(G).todense().astype(np.float64)) for G in [G1k, G2k]]
>>> y =[tfw(G) for  G in [G1k, G2k]]

It's a lot faster!

>>> [q for p,q in x]
[0.283782958984375, 1.0598750114440918]
>>> [q for p,q in y]
[5.002216100692749, 49.0821008682251]

And it works!

>>> mat_eq(x[0][0],y[0][0])
True
>>> mat_eq(x[1][0],y[1][0])
True
'''