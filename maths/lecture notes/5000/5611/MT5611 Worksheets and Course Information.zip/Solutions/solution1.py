#!/usr/bin/env python

# These are model solutions to the problems on Sheet 1
# 10/01/2017

# Problem 1
print "Hello, world!"
# prints Hello, world!

# Problem 2
123456 * 6543232321
# returns 807801289421376

# Problem 3
10 / 0
# prints the following:
# Traceback (most recent call last):
#   File "<stdin>", line 1, in <module>
# ZeroDivisionError: integer division or modulo by zero

# Problem 4
1234 ** 5
# returns 2861381721051424

# Problem 5
import math
math.sqrt(10)
# returns 3.1622776601683795

# Problem 6
2 + 3
# returns the number 5
"2" + "3"
# returns the string "23"

# Problem 7
538575 % 19
# returns 1
1989581 % 812497
# returns 364587

# Problem 8
248 % 7
# returns 3 which equals Thursday

# Problem 9
# The _ holds the last value returned from Python

# Problem 10
# x += 10 adds 10 to the value of the variable x. This is called in place
#         addition
# *=  multiplies in place
# -=  subtracts in place
# /=  divides in place

# Problem 11
s = ("EFsWKsHsFeHnUeBFDNbOlsibssxldejvDRoCWcjfj,IXOAhy "
     + "KlrdRdWKVpovHoPIgIbOrFcjyLGlWdCCARd")
s[6::7]
# returns 'Hello, World'

# Here is some information about so-called array slicing. We will cover this
# again in Class number 3.

# seq[:]                # [seq[0],   seq[1],          ..., seq[-1]    ]
# seq[low:]             # [seq[low], seq[low+1],      ..., seq[-1]    ]
# seq[:high]            # [seq[0],   seq[1],          ..., seq[high-1]]
# seq[low:high]         # [seq[low], seq[low+1],      ..., seq[high-1]]
# seq[::stride]         # [seq[0],   seq[stride],     ..., seq[-1]    ]
# seq[low::stride]      # [seq[low], seq[low+stride], ..., seq[-1]    ]
# seq[:high:stride]     # [seq[0],   seq[stride],     ..., seq[high-1]]
# seq[low:high:stride]  # [seq[low], seq[low+stride], ..., seq[high-1]]

# Problem 12
import random, string
h = "I love python"
s = ""

for i in xrange(12):
    for j in xrange(6):
        s += random.choice(string.letters)
    s += h[i]
s
# returns something like 'gpzDvaImOXefS kJqGIwlrvgjNQogzIrDHvzEPhJKeLJiNCX
# EsUqkiplijyINyrCouXLtUyPYxAhKCGcsCo'
