#!/usr/bin/env python

# These are model solutions to the problems on Sheet 2
# 12/01/2017
import math, random

# Section 2.1

# Problem 1
"1" * 10
# returns '1111111111'
# This is since multiplication is just repeated addition and "1" + "1" is "11".

# Problem 2
True + True
# returns 2
1 + True
# returns 2
3.1 + True
# returns 4.1

# Problem 3
0.1 + 0.2
# returns 0.30000000000000004

# Problem 4
1.0 / 2
# returns 0.5

# Problem 5
x = 1
y = 2
y / 2 = x
#  File "<stdin>", line 1
#SyntaxError: can't assign to operator

# Problem 6
True = 0
True == False
# returns True, which is False, so is this true or false, I don't know anymore!
# You better quit and start again if you wrote the above in the Python
# interpreter

# Problem 7
bool(str(int(float(False))))
# returns True

# Problem 8
x = 1
int(str(x + 5) * 3
# returns 666

# Problem 9
x = "4"
int(str(10 * int(x)) + "2")
# returns 402

# Problem 10
# The following code is not valid because in line 2, the statement print is not
# indented 4 spaces, but rather 3. Here is the correct code:
if x == 42:
   print "the meaning of life"
else:
   print nothing

# Problem 11

# The following code is not valid because the line after an else: has to be
# indented 4 spaces and this is not the case here. It is not clear what was
# intended here. Here are two different correct bits of code, what is the
# difference?

# Version 1
if x == 42:
   print "the meaning of life"
else:
   print 666

# Version 2
if x == 42:
   print "the meaning of life"
print 666

# Problem 12

# In the following, for whatever reason "False" evaluates so that the condition
# is satisfied, but it is not equal to True, and so the second print statement
# is not executed.
if str(False):
    print "wait why is this printed?"
if str(False) == True:
    print "wait why is this not printed?"

# Problem 13
if str(x) == x:
    print "it's a string"
else:
    print "it's not a string"

# Problem 14
out = ""
for i in xrange(1000):
    out += str(random.choice(range(10)))

out = int(out)
# out is a 1000 digit number

# Problem 15
sum = 0
for x in xrange(1024):
    if (x % 3) == 0 and (x % 5) != 0:
        sum += x
    elif (x % 5) == 0 and (x % 3) != 0:
        sum += x
# the answer is 209103

# Problem 16
# First a bit of maths:
#
#      x ^ 2 - xy + y ^ 2 = (x ^ 2 + y ^ 2 + (x - y) ^ 2) / 2
#
# and so
#
#      x ^ 2 + y ^ 2 <= 314
# and so there are only finitely many values of x and y to check: those in the
# range [-18, 18] (where 18 = sqrt{314}).

ans = []
for x in xrange(-18, 19):
    for y in xrange(-18, 19):
        if x * x + y * y - x * y == 157:
            ans.append([x, y])

# The answer is [[-13, -12], [-13, -1], [-12, -13], [-12, 1], [-1, -13],
# [-1, 12], [1, -12], [1, 13], [12, -1], [12, 13], [13, 1], [13, 12]]

# Problem 17
_LUCAS = [2, 1]

def lucas(n):
    if n >= len(_LUCAS):
        _LUCAS.insert(n, lucas(n - 1) + lucas(n - 2))
    return _LUCAS[n]

n = 0
while True:
    n += 1
    if len(str(lucas(n))) == 6001:
        break
# The answer is 28710
