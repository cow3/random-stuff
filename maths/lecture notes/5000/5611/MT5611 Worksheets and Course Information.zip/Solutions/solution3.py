#!/usr/bin/env python

# These are model solutions to the problems on Sheet 3

import math

# Problem 1
total = 0.0
aim   = round(math.pi ** 2 / 6, 5)
n = 1
while round(total, 5) != aim:
    total += 1.0 / (n * n)
    n += 1

# n has value 110293.

# Problem 2
print "99 bottles of beer on the wall, 99 bottles of beer."
for i in xrange(98, 0, -1):
    print "Take one down, pass it around,", i, "bottles of beer on the wall"
    print i, "bottles of beer on the wall,", i, "bottles of beer"

print "Take one down, pass it around, no more bottles of beer on the wall"
print "No more bottles of beer on the wall, no more bottles of beer"
print "Go to the store and buy some more, 99 bottles of beer on the wall"

# Problem 3
out = "*"
for i in xrange(20):
    print out
    out += "*"

# Problem 4
# At least two things are wrong with this code fragement:
#
# for x from 1 to 10: # this is not valid python
#   x = x + 1         # this line is not correctly indented
#    print x
#
# It should look like:

for x in xrange(1, 11):
    x = x + 1
    print x

# Problem 5
list = [136, 75, 209, 295, 96, 571, 90, 688, 959, 702, 855, 115, 846, 302, 179,
        953, 333, 174, 30, 111]
list.sort()
list
# returns [30, 75, 90, 96, 111, 115, 136, 174, 179, 209, 295, 302, 333, 571,
# 688, 702, 846, 855, 953, 959]

# Problem 6
s = "SwqFSWsgsecDQpcYnGareNnueDKDHtghfw kszEmrFTCeglCBsHmzusIWVUaIkRXgLNcde"
s[4::5]
# returns 'Secret message'

# Problem 7
cards = range(1, 53)
shuf  = []
for i in xrange(26):
    shuf.append(cards[i])
    shuf.append(cards[i + 26])

# Problem 8
def max_list(lst):
    assert isinstance(lst, list)
    max_val_in_list = 0
    for x in lst:
        assert isinstance(x, int) or isinstance(x, float)
        if x > max_val_in_list:
            max_val_in_list = x
    return max_val_in_list

max_list( [209, 295, 96, 571, 90])
# returns 571
max_list( [209.9, 295.9, 96.1331, 571.134, 909.1484])
# returns 909.1484
max_list(["asjdas", 131, 1414, 41525, 152])
# gives an assertion error

# Problem 9
def list_sum_for(lst):
    assert isinstance(lst, list)
    sum_vals_in_lst = 0
    for x in lst:
        assert isinstance(x, int) or isinstance(x, float)
        sum_vals_in_lst += x
    return sum_vals_in_lst

def list_sum_while(lst):
    assert isinstance(lst, list)
    sum_vals_in_lst = 0
    pos = 0
    while pos < len(lst):
        x = lst[pos]
        assert isinstance(x, int) or isinstance(x, float)
        sum_vals_in_lst += x
        pos += 1
    return sum_vals_in_lst

list_sum_for([209, 295, 96, 571, 90])
# returns 1261
list_sum_while([209, 295, 96, 571, 90])
# returns 1261

# Problem 10
def list_rotate(lst, k):
    assert isinstance(lst, list)
    assert isinstance(k, int)
    k %= len(lst)
    return lst[k:] + lst[:k]

list_rotate(range(6), 2)
# returns [2, 3, 4, 5, 0, 1]
list_rotate(range(6), 199)
# returns [1, 2, 3, 4, 5, 0]

# Problem 11
def digits(n):
    assert isinstance(n, int)
    digits_of_n = []
    while n > 0:
        digits_of_n.insert(0, n % 10)
        n /= 10
    return digits_of_n

digits(11835819)
# returns [1, 1, 8, 3, 5, 8, 1, 9]

# Problem 12
units = ["", "one", "two", "three", "four", "five", "six", "seven", "eight",
         "nine"]
teens = ["ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen", "sixteen",
         "seventeen", "eighteen", "nineteen"]
prefix = ["blank", "blank", "twenty", "thirty", "forty", "fifty", "sixty",
        "seventy", "eighty", "ninety"]

def string_from_int(n):
    if n < 10:
        return units[n]
    elif n < 20:
        return teens[n - 10]
    elif n == 100:
        return "one hundred"
    else:
        return prefix[n / 10] + " " + units[n % 10]

numbers = map(lambda x: string_from_int(x), range(1, 101))
result = map(lambda x: string_from_int(x), range(1, 101))
result.sort()
result = map(lambda x: numbers.index(x) + 1, result)

# Problem 13
def arrangeit(numbers):
    # Convert each number to a string: [50, 2, 1, 9] -> ['50', '2', '1', '9']
    numbers = map(str, numbers)
    # Sort: ['50', '2', '1', '9'] -> ['1', '2', '50', '9']
    numbers.sort()
    # Reverse: ['1', '2', '50', '9'] -> ['9', '50', '2', '1']
    numbers.reverse()
    # Concatenate and convert to int: ['9', '50', '2', '1'] -> '95021' -> 95021
    return int("".join(numbers))

# Check that it really works
arrangeit([50, 2, 1, 9])
# returns 95021
arrangeit([ 72, 44, 47, 33, 55, 79, 21, 99, 3, 30 ])
# returns 9979725547443330321L

# Problem 14
# Given that there are 9 digits and 3 possible values to insert between to
# digits (nothing, +, or -) there are a total of 3 ** 8 = 6561 so we'll just
# produce them all. In other words, we will produce all 8-tuples of the
# strings "", "+", "-", then interleave these with the numbers 1 to 9, then
# evaluate the resulting string and check if it is 100.

def next_tuple(tup):
    '''Takes a tuple and returns the next one in the sequence, i.e. if tup is
    ["", "", "", ..., ""], then next_tuple returns ["", "", ..., "+"]'''
    # assert
    for i in xrange(len(tup) - 1, -1, -1):
        if tup[i] == "-":
            tup[i] = ""
        elif tup[i] == "":
            tup[i] = "+"
            break
        elif tup[i] == "+":
            tup[i] = "-"
            break
    return tup

def plusminus():
    tup = [''] * 8
    while tup != ['-'] * 8:
        tup = next_tuple(tup)
        nxt = ['1']
        for i in xrange(8):
            nxt.append(tup[i])
            nxt.append(str(i + 2))
        nxt = "".join(nxt)
        if eval(nxt) == 100:
            print nxt, "=", eval(nxt)
