#!/usr/bin/env python

# These are model solutions to the problems on Sheet 4

import math

# Problem 1
def check_sum(n):
    '''Returns the sum of the digits of the integer n.'''
    assert isinstance(n, int)   # Check that n is an integer
    total = 0                   # The sum of the digits
    while n > 0:
        total += n % 10         # Add the last digit of n to total
        n /= 10                 # Divide n by 10
    return total

# Some examples . . .
check_sum(1233)
# Returns 9
check_sum(123)
# Returns 6
check_sum(193740817350)
# Returns 48
# Double check . . .
1 + 9 + 3 + 7 + 4 + 8 + 1 + 7 + 3 + 5;
# returns 48
check_sum(-1213)
# Returns 0, it is not really defined in the question what should happen here,
# i.e. should it be -1 + 2 + 1 + 3, or 1 + 2 + 1 + 3, or what? So this is as
# good an answer as anything.

# Problem 2
def weird(n):
    '''Returns the product of the digits of the integer n.'''
    assert isinstance(n, int)  # Check that n is an integer
    total = 1                  # The product of the digits plus 1
    while n > 0:
        total *= 1 + (n % 10)  # Multiply the total by the last digit + 1
        n /= 10                # Divide n by 10
    return total

# Some examples . . .
weird(123)
# Returns 24
weird(123333)
# Returns 1536
weird(13813)
# Returns 576
weird(-123)
# Returns 1, same comment as for Problem 1.

# Problem 3
def gcd(a, b):
    '''Computes the greatest common divisor of the integers a and b.'''
    assert isinstance(a, int) and isinstance(b, int)
    while b != 0:
        a, b = b, a % b
    return a

# Some examples . . .
gcd(25, 5)
# Returns 5
gcd(2, 3)
# Returns 1
gcd(123, 3)
# Returns 3
gcd(123, 7)
# Returns 1
gcd(2744, 133)
# Returns 7

# Problem 4
a = 1.0
for n in xrange(1, 21):
    print "Term", n, "is", a
    a = 5 * a / 4 + 1
# Prints
# Term 1 is 1.0
# Term 2 is 2.25
# Term 3 is 3.8125
# Term 4 is 5.765625
# Term 5 is 8.20703125
# Term 6 is 11.2587890625
# Term 7 is 15.0734863281
# Term 8 is 19.8418579102
# Term 9 is 25.8023223877
# Term 10 is 33.2529029846
# Term 11 is 42.5661287308
# Term 12 is 54.2076609135
# Term 13 is 68.7595761418
# Term 14 is 86.9494701773
# Term 15 is 109.686837722
# Term 16 is 138.108547152
# Term 17 is 173.63568394
# Term 18 is 218.044604925
# Term 19 is 273.555756156
# Term 20 is 342.944695195

a = 1.0
total = 0.0
for n in xrange(1, 101):
    total += a
    a = 5 * a / 4 + 1

total
# Returns 98181868885.95459

# For the last two parts of the question you will have to experiment!

# Problem 5

def primes(n):
    '''Returns a list where the item with index n is True if the integer n is a
       prime. This is a translation of the pseudocode from wikipedia:
       https://en.wikipedia.org/wiki/Sieve_of_Eratosthenes'''
    assert isinstance(n, int)
    A = [True for x in xrange(n)]
    for i in xrange(2, int(math.sqrt(n)) + 1):
        if A[i]:
            for j in xrange(i ** 2, n, i):
                A[j] = False
    return A

def betrand(n):
    '''Returns True if Betrand's postulate is true, and False otherwise.'''
    assert isinstance(n, int)
    is_prime = primes(2 * n + 1)
    for i in xrange(1, n + 1):
        for j in xrange(i, 2 * i + 1):
            if is_prime[j]:
                break
        else:
            print "Betrand's postulate is False!"
            return False
    return True

betrand(3 * 10 ** 6)
# Returns True

# The numbers
#
#   2, 3, 5, 7, 13, 23, 43, 83, 163, 317, 631, 1259, 2503, 4001
#
# are all prime (check it!) and each is less than twice the previous (check
# this too). So, if n is any number between 1 and 4000, then there are two
# consecutive numbers a and b in the list such that a <= n <= b. Hence
# n <= b < 2a <= 2n, and so b is a prime number between n and 2 * n.

# Problem 6
def myapply(funcs, x):
    '''Returns the list [f_1(x), ..., f_n(x)] where funcs = [f_1, ..., f_n] and
    each of the f_i is Python function.'''
    assert isinstance(funcs, list) # Check that funcs is a list
    out = []                       # The list we will output
    for func in funcs:
        assert callable(func)      # Weakly check that func is a function
        out.append(func(x))        # Append to the output list
    return out

# Some examples . . .
myapply([weird, check_sum], 1234)
# Returns [120, 10]

myapply([weird, check_sum, lambda x: x ** 2], 10)
# Returns [2, 1, 10]

def check_sum2(n):
    '''Prints the sum of the digits of the integer n.'''
    assert isinstance(n, int)
    total = 0
    while n > 0:
        total += n % 10
        n /= 10
    print total

def weird2(n):
    '''Prints the product of the digits of the integer n.'''
    assert isinstance(n, int)
    total = 1
    while n > 0:
        total *= 1 + (n % 10)
        n /= 10
    print total

myapply([weird2, check_sum2], 1234)
# Prints
# 120
# 10
# And then returns:
# [None, None]
# Since weird2 and check_sum2 do not return anything at all, the value None is
# used instead.

# Problem 7
def fold_left(lst, func, init):
    assert isinstance(lst, list) and callable(func)
    acc = init;
    for x in lst:
        acc = func(acc, x);
    return acc

lst = [-12, 5, -72, -18, 92]

# Part (a)
def myprod(lst):
    assert isinstance(lst, list)
    return fold_left(lst, lambda x, y: x * y, 1)

# Some examples . . .
myprod([1, 2, 3])
# Returns 6
myprod(lst)
# Returns -7153920

# Part (b)
def mymax(lst):
    assert isinstance(lst, list)
    return fold_left(lst, lambda x, y: [x, y][x < y], 0)

# You might have to think a little bit about what is happening in
# [x, y][x < y]! Thanks to Fin Smith for point this out to me.

# Some examples . . .
mymax([1, 2, 3])
# Returns 3
mymax(lst)
# Returns 92

# Part (c)
def mylast(lst):
    assert isinstance(lst, list)
    return fold_left(lst, lambda x, y: y, None)

# Some examples . . .
mylast([1, 2, 3])
# Returns 3
mylast(lst)
# Returns 92
mylast(range(1000))
# Returns 999
mylast([]) == None
# Returns True

# Part (d)

def myrev(lst):
    assert isinstance(lst, list)
    def foo(acc, x):
        acc.insert(0, x)
        return acc
    return fold_left(lst, foo, [])

# Some examples . . .
myrev([1, 2, 3])
# Returns [3, 2, 1]
mylast(lst)
# Returns [92, -18, -72, 5, -12]
mylast([])
# Returns []

# Part (e)

def mycount(lst, val):
    assert isinstance(lst, list)
    def foo(acc, x):
        if x == val:
            return acc + 1
        else:
            return acc
    return fold_left(lst, foo, 0)

# Some examples . . .
mycount([1,1,1,1,1,1,1,2,2,2,3,4,4,25,1,41,4], 1)
# Returns 8
mycount([1,1,1,1,1,1,1,2,2,2,3,4,4,25,1,41,4], 2)
# Returns 3
mycount([1,1,1,1,1,1,1,2,2,2,3,4,4,25,1,41,4], 41)
# Returns 1

# Problem 8

def partition_by_func(lst, func):
    '''Returns a list which is a partition of lst according to the value of the
    function func.'''
    assert isinstance(lst, list) and callable(func)
    lookup = {}     # A dictionary for keeping track of which values of func
                    # correspond to which positions in lookup
    partition = []  # The partition we will output
    for x in lst:
        val = func(x)     # Apply the function func to x
        if val in lookup: # Check if there are already items y with func(y) ==
                          # val in the partition.
            partition[lookup[val]].append(x)
        else:
            lookup[val] = len(partition)
            partition.append([x])
    return partition

# Some examples . . .
partition_by_func(range(1, 11), lambda x: x % 2)
[[1, 3, 5, 7, 9], [2, 4, 6, 8, 10]]

# Problem 9
i = 1
def f(n):
    total = 0
    for i in xrange(1, 11):
        total + i
    return total

f(10)
# Returns 0, the reason for this is that we do not say total = total + i so the
# sum in line 3 of the function f, is not recorded anywhere.
i
# Returns 1, this is because the i inside the function f is not the same as the
# i outside. The particular value the variable i has depends on something
# called scope. Scope is just the part of the program where the assignment
# of a variable to a value is valid. We define i = 1 in the global scope (i.e.
# valid everywhere), and then we define it again in the scope of the function
# f. The innermost declaration (or narrowest scope) is the one which takes
# precedence here, and so the value of i inside the function is the value it is
# assigned within the function.

# Problem 10

def new_counter():
    c = [0]
    def counter():
        c[0] += 1
        return c[0]
    return counter

# The function new_counter returns a function that takes no arguments, which
# whenever it is called returns the next integer after the last one returned,
# starting with 1. For example:

counter = new_counter()
counter()
# Returns 1
counter()
# Returns 2
counter()
# Returns 3
counter()
# Returns 4
counter = new_counter()
counter()
# Returns 1
counter()
# Returns 2
counter()
# Returns 3
counter()
# Returns 4
counter()
# Returns 5
counter()
# Returns 6

def newer_counter():
    c = 0
    def counter():
        c += 1
        return c
    return counter

counter = newer_counter()
counter()
# Gives the following error
# Traceback (most recent call last):
#  File "<stdin>", line 1, in <module>
#  File "<stdin>", line 4, in counter
# UnboundLocalError: local variable 'c' referenced before assignment

# This is again an issue of scope, the variable c is defined in the scope of
# the function newer_counter, then it is used in the scope of counter where it
# is not defined. The same is true of the function newer_counter, the key
# difference is that the value (0) of c in newer_counter cannot be changed, it
# is immutable, while in new_counter the value ([0]) of c is mutable, and so
# the inner function counter can modify it!

# This is all a bit complicated, but is meant to illustrate that you have to be
# careful when using variables from an outer scope in Python.
