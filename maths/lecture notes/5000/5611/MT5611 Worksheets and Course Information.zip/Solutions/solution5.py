#!/usr/bin/env python
# pylint: skip-file
# These are model solutions to the problems on Sheet 5

import math
import time
import matplotlib.pyplot as plt
import random

# Problem 1
# Part (a)

def primes(n):
    '''Returns a list of the primes less than n. This is a translation of the
      pseudocode from wikipedia:
      https://en.wikipedia.org/wiki/Sieve_of_Eratosthenes'''
    assert isinstance(n, int)
    A = [True for x in xrange(n)]
    for i in xrange(2, int(math.sqrt(n)) + 1):
        if A[i]:
            for j in xrange(i ** 2, n, i):
                A[j] = False
    return [p for p in xrange(2, n) if A[p]]

def nr_primes_last_digit(n):
    result = [0] * 10
    for p in primes(n):
        result[p % 10] += 1
    return result

# Some examples . . .
nr_primes_last_digit(20)
# Returns [0, 1, 1, 2, 0, 1, 0, 2, 0, 1]
nr_primes_last_digit(100000)
# [0, 2387, 1, 2402, 0, 1, 0, 2411, 0, 2390]

# Part (b)
# The bar chart of the data
plt.bar(range(10), [0, 2387, 1, 2402, 0, 1,
                    0, 2411, 0, 2390], 1, align='center')
plt.xlabel('Number of primes')
plt.ylabel('Last digit')
plt.xticks(range(10))
plt.xlim(-0.5, 10.5)
plt.show()

# Part (c)

def nr_primes_mod_4(n):
    result = [0] * 4
    for p in primes(n):
        result[p % 4] += 1
    return result

nr_primes_mod_4(100000)
# Returns [0, 4783, 1, 4808]
# So the answer is there are more primes of the form 4k + 3.

# Problem 2

def solve_problem_2():
    result = []
    for x in xrange(100000):
        result.append(random.randint(-101, 101))
    return result

cm = plt.cm.get_cmap('viridis')
n, bins, patches = plt.hist(solve_problem_5(), 400,
                            normed=1, color='green', edgecolor="none")

bin_centers = 0.5 * (bins[:-1] + bins[1:])

# scale values to interval [0,1]
col = bin_centers - min(bin_centers)
col /= max(col)

for c, p in zip(col, patches):
    plt.setp(p, 'facecolor', cm(c))

plt.show()

# Problem 3

import random

def H(dummy):
    result = []
    for x in xrange(100):
        result.append(random.randint(0, 1))
    return result.count(0)

data = map(H, xrange(1000))
plt.hist(data, xrange(0, 101))
plt.show()

# Problem 4
# Similar to Problem 1.4.4.1 on
# http://www.scipy-lectures.org/intro/matplotlib/matplotlib.html

theta = np.arange(-2 * np.pi, 2 * np.pi, 0.01)
r = 2 * (1 + np.cos(theta))
plt.fill_between(r, theta, color='red', alpha=.35)
plt.plot(r, theta)
plt.grid(False)
plt.axis([-1, 5, -8, 8])
plt.xticks(())
plt.yticks(())
plt.show()

# Problem 5
# Similar to Problem 1.4.4.2 on
# http://www.scipy-lectures.org/intro/matplotlib/matplotlib.html

n = 1024
X = np.random.normal(0, 1, n)
Y = np.random.normal(0, 1, n)
T = np.arctan2(Y, X)

plt.axes([0.025, 0.025, 0.95, 0.95])
plt.scatter(X, Y, s=50, c=T, alpha=.5)

plt.xticks(())
plt.yticks(())

plt.show()

# Problem 6

x = arange(-10., 10., 0.1)
f = x ** 2 - 4
g = -2 * x - 2
plt.plot(x, f)
plt.plot(x, g)
plt.grid(True)
plt.axis([-5, 2, -10, 10])
idx = np.argwhere(np.diff(np.sign(f - g)) != 0).reshape(-1) + 0
plt.plot(x[idx], f[idx], 'ro')
plt.plot(x[idx], g[idx], 'ro')
plt.show()

# Problem 7

def nr_primes(n):
    '''Returns the number of primes less than n.'''
    assert isinstance(n, int)
    A = [True for x in xrange(n)]
    for i in xrange(2, int(math.sqrt(n)) + 1):
        if A[i]:
            for j in xrange(i ** 2, n, i):
                A[j] = False
    return A[2:].count(True)

X = xrange(2, 1001)
Y = map(nr_primes, X)
plt.plot(X, Y, "r-")
plt.plot(X, map(lambda x: int(float(x) / math.log(x)), X), "g-")

# Take a look at https://en.wikipedia.org/wiki/Prime_number_theorem
