#!/usr/bin/env python
# pylint: skip-file
# These are model solutions to the problems on Sheet 5

import math
import time
import matplotlib.pyplot as plt
import random

# Problem 1

foo1 = lambda L: sum(L)

def foo2(L):
    'Returns the sum of the values in the list L.'
    result = 0
    for x in L:
        result += x
    return result

def foo3(L):
    'Returns the sum of the values in the list L.'
    result = 0
    for i in xrange(len(L)):
        result = result + L[i]
    return result

def foo4(L):
    'Returns the sum of the values in the list L.'
    result = 0
    for i in range(len(L)):
        result = result + L[i]
    return result

def foo5(L):
    'Returns the sum of the values in the list L.'
    result = 0
    i = 1
    while i < len(L):
        result = result + L[i]
        i = i + 1
    return result

def benchmark(func, arg, trials = 1):
    '''
    Returns a list of floats (of length trials) indicating the time taken in
    milliseconds to run func(arg).
    '''
    result = []
    for n in xrange(trials):
        start = time.time()
        func(arg)
        end = time.time()
        result.append((end - start) * 1000)
    return result

def mean_time(func, arg, trials = 1):
    return sum(benchmark(func, arg, trials)) / trials


X = xrange(1, 101)
data1 = map(lambda n: mean_time(foo1, xrange(10000 * n), 5), X)
data2 = map(lambda n: mean_time(foo2, xrange(10000 * n), 5), X)
data3 = map(lambda n: mean_time(foo3, xrange(10000 * n), 5), X)
data4 = map(lambda n: mean_time(foo4, xrange(10000 * n), 5), X)
data5 = map(lambda n: mean_time(foo5, xrange(10000 * n), 5), X)

plt.plot(X, data1, 'gx', label='foo1') # green
plt.plot(X, data2, 'bx', label='foo2') # blue
plt.plot(X, data3, 'rx', label='foo3') # red
plt.plot(X, data4, 'kx', label='foo4') # black
plt.plot(X, data5, 'mx', label='foo5') # magenta
plt.title("Comparison of the runtimes of foo1 to foo5")
plt.legend(loc="upper left")
plt.xlabel("Argument xrange(10000 * n) for n = 1, ... , 100.")
plt.ylabel("Time (ms).")

# Problem 2

def benchmark(func, func_arg):
    start = time.time()
    func(func_arg)
    end = time.time()
    return end - start

def primes(n):
    '''
    Returns a list of the primes less than n. This is a translation of the
    pseudocode from wikipedia:
    https://en.wikipedia.org/wiki/Sieve_of_Eratosthenes
    '''
    assert isinstance(n, int)
    A = [True for x in xrange(n)]
    for i in xrange(2, int(math.sqrt(n)) + 1):
        if A[i]:
            for j in xrange(i ** 2, n, i):
                A[j] = False
    return [p for p in xrange(2, n) if A[p]]

times = map(lambda n: benchmark(primes, n), xrange(10000, 1000000, 10000))
linear = map(lambda n: times[0] * n / 10000, xrange(10000, 1000000, 10000))
nloglogn = map(
    lambda n: times[0] *
    n *
    math.log(
        math.log(n)) /
    10000,
    xrange(
        10000,
        1000000,
        10000))

plt.plot(times, 'bo', linear, 'g--', nloglogn, 'r--')
plt.xlabel('primes(n * 10000)')
plt.ylabel('time in seconds')
plt.show()

# Problem 3

def find_solutions(start, stop):
    result = []
    for x in xrange(start, stop):
        for y in xrange(x + 1, stop):
            for z in xrange(start, stop):
                for t in xrange(z + 1, stop):
                    if x != z and x ** 3 + y ** 3 == z ** 3 + t ** 3:
                        result.append([x, y, z, t])
    return result

find_solutions(1, 31)
# Returns [[1, 12, 9, 10], [2, 16, 9, 15], [2, 24, 18, 20], [9, 10, 1, 12],
#          [9, 15, 2, 16], [10, 27, 19, 24], [18, 20, 2, 24], [19, 24, 10, 27]]

# Problem 4
# Part (a)

def pythagorean_triples(n):
    '''
    Returns a list of all the Pythagorean triples (x, y, z) where x, y, z < n.
    '''
    assert isinstance(n, int) and n > 0
    result = []
    for x in xrange(n):
        for y in xrange(x + 1, n):
            for z in xrange(y + 1, n):
                if x * x + y * y == z * z:
                    result.append([x, y, z])
    return result

pythagorean_triples(100)
# Returns [[3, 4, 5], [5, 12, 13], [6, 8, 10], [7, 24, 25], [8, 15, 17], [9,
# 12, 15], [9, 40, 41], [10, 24, 26], [11, 60, 61], [12, 16, 20], [12, 35, 37],
# [13, 84, 85], [14, 48, 50], [15, 20, 25], [15, 36, 39], [16, 30, 34], [16,
# 63, 65], [18, 24, 30], [18, 80, 82], [20, 21, 29], [20, 48, 52], [21, 28,
# 35], [21, 72, 75], [24, 32, 40], [24, 45, 51], [24, 70, 74], [25, 60, 65],
# [27, 36, 45], [28, 45, 53], [30, 40, 50], [30, 72, 78], [32, 60, 68], [33,
# 44, 55], [33, 56, 65], [35, 84, 91], [36, 48, 60], [36, 77, 85], [39, 52,
# 65], [39, 80, 89], [40, 42, 58], [40, 75, 85], [42, 56, 70], [45, 60, 75],
# [48, 55, 73], [48, 64, 80], [51, 68, 85], [54, 72, 90], [57, 76, 95], [60,
# 63, 87], [65, 72, 97]]
len(pythagorean_triples(100))
# Returns 50

# Part (b)

def solve_it():
    for x in xrange(1, 999):
        for y in xrange(1, 999):
            if (x + y) < 1000:
                z = (1000 - x) - y
                if x * x + y * y == z * z:
                    return [x, y, z]
solve_it()
# Returns [200, 375, 425]

# Problem 5

def is_happy_number(n):
    '''
    Returns True if n is a happy number and False if it is not.
    '''
    assert isinstance(n, int) and n > 0

    def f(n):
        total = 0
        while n != 0:
            total += (n % 10) ** 2
            n /= 10
        return total
    while f(n) != 1 and f(n) != 4:
        n = f(n)
    return f(n) == 1

[p for p in primes(1000) if is_happy_number(p)]
# Returns [7, 13, 19, 23, 31, 79, 97, 103, 109, 139, 167, 193, 239, 263, 293,
# 313, 331, 367, 379, 383, 397, 409, 487, 563, 617, 653, 673, 683, 709, 739,
# 761, 863, 881, 907, 937]

# Problem 6
# Part (a)

def solve_6a():
    for x in xrange(1000, 10000):
        y = int(str(x)[1:3])
        if y ** 2 == x:
            return x
solve_6a()
# Returns 2500

# Part (b)

def solve_6b():
    for x in xrange(1000, 10000):
        y = int(str(x)[0] + str(x)[-1])
        if y ** 2 == x:
            return x
solve_7b()
# Returns 9025

# Problem 7
alphabet = "abcdefghijklmnopqrstuvwxyz 1234567890.,"
morse = [".-", "-...", "-.-.", "-..", ".", "..-.", "--.", "....", "..", ".---",
        "-.-", ".-..", "--", "-.", "---", ".--.", "--.-", ".-.", "...", "-",
        "..-", "...-", ".--", "-..-", "-.--", "--..", "|", ".----", "..---",
        "...--", "....-", ".....", "-....", "--...", "---..",
        "----.", "-----", ".-.-.-", "--..--"]
alphabet_to_morse = {a: m for a, m in zip(alphabet, morse)}
morse_to_alphabet = {m: a for a, m in zip(alphabet, morse)}

def translate_english_to_morse(string):
    '''
    Returns the argument string translated into Morse code. This will fail if
    the string contains a character that is not in the variable alphabet.
    Capitalisation is not preserved.
    '''
    assert isinstance(string, str)
    result = ""
    for char in string.replace('\n', ' '):
        if result:
            result += " "
        result += alphabet_to_morse[char.lower()]
    return result


def translate_morse_to_english(string):
    '''
    Returns the argument string translated from Morse code back into English.
    This will fail if string is not a properly formed Morse code message.
    '''
    assert isinstance(string, str)

    result = ""
    words = string.split("|")  # split into words
    for word in string.split("|"):
        if result:
            result += " "
        word = word.strip()
        for letter in word.split(" "):
            result += morse_to_alphabet[letter]
    return result

# An example:
message = """Brunch mixtape yuccie drinking vinegar unicorn VHS four loko
raclette prism hexagon keffiyeh. Artisan forage cred prism vice, twee
pork belly helvetica bitters master cleanse selfies. 8 bit selvage four
loko chambray seitan, tousled dreamcatcher leggings cronut. Vinyl prism
gastropub craft beer typewriter food truck. Unicorn jean shorts mixtape,
trust fund tumeric PBR waistcoat stumptown ugh migas pop up artisan
austin schlitz. Art party marfa lumbersexual street art, sartorial
actually thundercats."""

translate_english_to_morse(message)
# Returns
# '-... .-. ..- -. -.-. .... | -- .. -..- - .- .--. . | -.-- ..- -.-. -.-. .. . |
# -.. .-. .. -. -.- .. -. --. | ...- .. -. . --. .- .-. | ..- -. .. -.-. --- .-.
# -. | ...- .... ... | ..-. --- ..- .-. | .-.. --- -.- --- | .-. .- -.-. .-.. . -
# - . | .--. .-. .. ... -- | .... . -..- .- --. --- -. | -.- . ..-. ..-. .. -.--
# . .... .-.-.- | .- .-. - .. ... .- -. | ..-. --- .-. .- --. . | -.-. .-. . -..
# | .--. .-. .. ... -- | ...- .. -.-. . --..-- | - .-- . . | .--. --- .-. -.- |
# -... . .-.. .-.. -.-- | .... . .-.. ...- . - .. -.-. .- | -... .. - - . .-. ...
# | -- .- ... - . .-. | -.-. .-.. . .- -. ... . | ... . .-.. ..-. .. . ... .-.-.-
# | ---.. | -... .. - | ... . .-.. ...- .- --. . | ..-. --- ..- .-. | .-.. ---
# -.- --- | -.-. .... .- -- -... .-. .- -.-- | ... . .. - .- -. --..-- | - ---
# ..- ... .-.. . -.. | -.. .-. . .- -- -.-. .- - -.-. .... . .-. | .-.. . --. --.
# .. -. --. ... | -.-. .-. --- -. ..- - .-.-.- | ...- .. -. -.-- .-.. | .--. .-.
# .. ... -- | --. .- ... - .-. --- .--. ..- -... | -.-. .-. .- ..-. - | -... . .
# .-. | - -.-- .--. . .-- .-. .. - . .-. | ..-. --- --- -.. | - .-. ..- -.-. -.-
# .-.-.- | ..- -. .. -.-. --- .-. -. | .--- . .- -. | ... .... --- .-. - ... | --
# .. -..- - .- .--. . --..-- | - .-. ..- ... - | ..-. ..- -. -.. | - ..- -- . .-.
# .. -.-. | .--. -... .-. | .-- .- .. ... - -.-. --- .- - | ... - ..- -- .--. -
# --- .-- -. | ..- --. .... | -- .. --. .- ... | .--. --- .--. | ..- .--. | .-
# .-. - .. ... .- -. | .- ..- ... - .. -. | ... -.-. .... .-.. .. - --.. .-.-.- |
# .- .-. - | .--. .- .-. - -.-- | -- .- .-. ..-. .- | .-.. ..- -- -... . .-. ...
# . -..- ..- .- .-.. | ... - .-. . . - | .- .-. - --..-- | ... .- .-. - --- .-.
# .. .- .-.. | .- -.-. - ..- .- .-.. .-.. -.-- | - .... ..- -. -.. . .-. -.-. .-
# - ... .-.-.-'
translate_morse_to_english(_)
# Returns
# 'brunch mixtape yuccie drinking vinegar unicorn vhs four loko raclette prism
# hexagon keffiyeh. artisan forage cred prism vice, twee pork belly helvetica
# bitters master cleanse selfies. 8 bit selvage four loko chambray seitan,
# tousled dreamcatcher leggings cronut. vinyl prism gastropub craft beer
# typewriter food truck. unicorn jean shorts mixtape, trust fund tumeric pbr
# waistcoat stumptown ugh migas pop up artisan austin schlitz. art party marfa
# lumbersexual street art, sartorial actually thundercats.'

# Problem 8

# This is not very efficient.
def longest_palindromic_substring(string):
    '''
    Returns the longest palindromic substring of the parameter string.
    '''
    assert isinstance(string, str)
    longest = 0
    result = ""
    for i in xrange(len(string) - 1): # prefix start index
        for j in xrange(i + 1, len(string)): # prefix stop index
            if (string[i:j] == string[j - 1: 2 * j - i - 1][::-1]):
                if 2 * (j - i) - 1 > longest:
                    longest =  2 * (j - i) - 1
                    result = string[i: 2 * j - i - 1]
                    print i, j
            elif (string[i:j] == string[j: 2 * j - i][::-1]):
                if 2 * (j - i) > longest:
                    longest =  2 * (j - i)
                    result = string[i:2 * j -i]
    return result

# Some examples
longest_palindromic_substring("123412345671234567890987654321")
# Returns '1234567890987654321'
longest_palindromic_substring("1234123456712345678900987654321")
# Returns '12345678900987654321'
longest_palindromic_substring("bananas")
# Returns "anana"
