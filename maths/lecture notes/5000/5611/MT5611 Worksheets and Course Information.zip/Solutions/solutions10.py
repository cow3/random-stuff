# These are the solutions to the problems in Worksheet 10.

# Question 1

import networkx as nx
import pylab as pyl

# Empty graph takes an integer n as input, and returns a 
# graph with no edges and nodes named 1..n
def EmptyGraph(n):
    g = nx.Graph()
    g.add_nodes_from(xrange(1, n+1))
    return g
    
e1 = EmptyGraph(1)
n1 = e1.nodes()
# n1 is now [1]
nx.draw(e1, with_labels = True)
pyl.show()

e5 = EmptyGraph(5)
n5 = e5.nodes()
# n5 is now [1, 2, 3, 4, 5]
nx.draw(e5, with_labels = True)
pyl.show()



# Question 2

# Following function takes as input a graph G, and returns
# the degree sequence of G

def DegreeSequence(G):
    return G.degree().values()
    
# Question 3

# We make a list of 5 lists of graphs.
graph_list = []
for i in [2, 4, 6, 8, 10]:
    new_list =[]
    for j in [0.2, 0.5, 0.8]:
        new_list.append(nx.erdos_renyi_graph(i, j))
    graph_list.append(new_list)   

sequences = []   
neighbours = [] 
for size in graph_list:
    new_sequences = []
    new_neighbours = []
    for g in size:
        nx.draw(g, with_labels = True)
        pyl.show()
        new_sequences.append(DegreeSequence(g))
        new_neighbours.append(g.neighbors(0))
    sequences.append(new_sequences)
    neighbours.append(new_neighbours)

# Produces lots of pretty pictures.
# For me, sequences is now [[[0, 0], [0, 0], [1, 1]],
# [[1, 1, 1, 1], [2, 2, 1, 3], [2, 2, 1, 3]],
# [[1, 0, 2, 1, 0, 0], [2, 3, 3, 4, 3, 3], [4, 5, 4, 5, 5, 5]],
# [[5, 0, 1, 1, 0, 1, 2, 2], [4, 3, 5, 2, 2, 4, 4, 4],[6, 4, 4, 6, 6, 5, 5, 6]],
# [[1, 1, 4, 2, 1, 2, 3, 2, 1, 5], [4, 3, 6, 3, 5, 3, 5, 3, 6, 4],
#  [9, 9, 8, 8, 9, 8, 9, 9, 8, 9]]]

# and neighbours is now
# [[[], [], [1]],
# [[3], [1, 3], [1, 3]],
# [[2], [3, 5], [1, 3, 4, 5]],
# [[2, 3, 5, 6, 7], [1, 3, 5, 7], [1, 2, 4, 5, 6, 7]],
# [[2], [8, 1, 2, 3], [1, 2, 3, 4, 5, 6, 7, 8, 9]]]      
# Question 4

# The required function is nx.is_connected(g)

connecteds = []
for size in graph_list:
    g_conn = []
    for g in size:
        g_conn.append(nx.is_connected(g))     
    connecteds.append(g_conn)

# for me, connecteds is now
#[[False, True, False],
# [False, True, True],
# [False, True, True],
# [True, True, True],
# [False, True, True]]

# Question 5
# Part (a)

# The following function takes as input a graph G and an
# integer d and returns a list of nodes of G of degree d
def Degd(G,d):
    nds = G.nodes()
    deg_d = []
    for x in nds:
        if G.degree(x)==d:
            deg_d.append(x)
    return deg_d
  
# Part (b)    
d3 = Degd(nx.erdos_renyi_graph(6, 0.5, seed=50), 3)
# d3 is now [1, 2, 3, 5]

# Part (c)
# The following function takes as input a graph G
# and returns a list of the integers of minimal degree.
def MinimalDegree(G):
    deg_seq = DegreeSequence(G) # find degrees of all the vertices
    min_deg = min(deg_seq)      # find the smallest degree that occurs
    return min_deg, Degd(G, min_deg) #find all vertices of that degree

# Part (d)
    
g1 = nx.erdos_renyi_graph(7, 0.3, seed=10)
MinimalDegree(g1)
# return(1, [0, 2, 4, 5])

g2 = nx.erdos_renyi_graph(7, 0.5, seed=10)
MinimalDegree(g2)
# return (2, [0, 2, 4])

g3 = nx.erdos_renyi_graph(7, 0.7, seed=10)
MinimalDegree(g3)
# return (3, [2])
   
# Question 6

# This function takes as input a graph G, and returns
# the subgraph of G that consists of only those vertices of
# G of maximum possible degree, with whatever edges existed between 
# them in G.

def MaxdegSubgraph(G):
    nds = G.nodes()
    edge_list = G.edges()
    deg_seq = DegreeSequence(G)
    max_deg = max(deg_seq)
    max_nodes = []
    for x in nds:
        if G.degree(x) == max_deg:
            max_nodes.append(x)
    new_g = nx.Graph()
    new_g.add_nodes_from(max_nodes)
    for e in edge_list:
        if e[0] in max_nodes:
            if e[1] in max_nodes:
                new_g.add_edge(e[0], e[1])
    return new_g
       
 # and now to run it
res_graphs = []
for size in graph_list:
    subgraphs = []
    for g in size:
        subgraphs.append(MaxdegSubgraph(g))   
    res_graphs.append(subgraphs)

 # One can now look at them one by one to check correctness  


        
   