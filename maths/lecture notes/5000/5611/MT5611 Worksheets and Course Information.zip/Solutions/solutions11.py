"""
Solutions to the problems in Worksheet 11
"""

import networkx as nx
import pylab as pyl

# Question 1

def ListConnected(G):
    #set up an empty dictionary
    d = dict()
    #put a key in it for each node, initially all 0
    for v in G.nodes():
        d[v] = 0
    d[G.nodes()[0]] = 1
    # a while loop will help us check whether we 
    # made any changes in the last pass through the graph.
    # This is clearer for someone else to read than using 
    # a "break" statement.
    added = True # makd sure we enter the while loop at least once!
    i = 1        # keep track of what pass we're on
    while added:
        added = False # this changes to true if we reach any 
                      # new nodes
        for x in d.keys():
            if d[x] == i:
                neighbs = G.neighbors(x) 
                for y in neighbs:
                    if d[y]==0:
                        d[y] = i+1
                        added = True
        i = i+1 # don't forget to update the pass number.
    for x in d.values():
        if x == 0:
            return False
    return True

# Making a list of 20 random graphs on 100 vertices, all 
# with edge probability 0.05.
graph_list = []
for i in xrange(20):
    graph_list.append(nx.erdos_renyi_graph(100, 0.05))


import time
times = []  
results = []  
    
# We'll check correctness using an "assert" statement - 
# provided that the code runs we know that all of the assertions
# were true, and so the answers are correct
for g in graph_list:
    start = time.time()
    c = ListConnected(g)
    end = time.time()
    times.append((end-start)*1000)
    results.append(c)
    assert (c == nx.is_connected(g))
    
# no assertions fail, so code probably works.     
# times are all between 0.14 and 0.19 milliseconds - pretty fast!

  
     
# Question 2

# Notice that in this function we don't actually ever need to 
# create the set W, we just loop through the nodes.
def PathConnected(G):
    adj1 = nx.adjacency_matrix(G)
    m = adj1.todense()
    v_range = G.number_of_nodes()
    for i in range(v_range): # this loop is keeping track of which 
                             # nodes are in the imaginary set W
        for j in range(v_range):
            # since matrix is symmetric, don't need to test k < j
            for k in range(j, v_range):
                if m[j,k]==0:
                    if ((m[i,j]==1) and (m[i,k]==1)):
                        m[j,k]=1
                        m[k,j]=1
    for i in range(v_range):
        for j in range(i+1, v_range):
            if (m[i,j] == 0):
                return False
    return True

# we already have the set of graphs
path_times = []
path_results = []
for g in graph_list:
    start = time.time()
    c = PathConnected(g)
    end = time.time()
    path_times.append((end-start)*1000)
    path_results.append(c)
    assert (c == nx.is_connected(g))

# massively slower - this is not a good way to test connectivity!
# But it does work, as all of the assertions succeed


# Question 3
def MyFloydWarshall(G):
    adj1 = nx.adjacency_matrix(G)
    m = adj1.todense()
    v_range = G.number_of_nodes()
    for i in range(v_range): #This is the nodes going into the set W
        for j in range(v_range):
            for k in range(j+1, v_range): # Leave diagonal entries as 0
                if ((m[i,j]>0) and (m[i,k]>0)):
                    dist = m[i,j] + m[i,k]
                    if ((m[j,k] == 0) or m[j,k] > dist):
                        m[j,k] = dist
                        m[k,j] = dist
    # now to deal with disconnected graphs - 
    # we'll use the convention that distance -1
    # means that there is no such path
    for i in range(v_range):
        for j in range(i+1, v_range):
            if m[i, j]==0:
                m[i, j] = -1
                m[j, i] = -1
    return m
                   

# Generate some test data - keep it reasonably small since we
# know from Q2 that this is much slower than just testing connectivity

warshall_list = []
for p in [0.1, 0.2, 0.4, 0.8]:
    for i in range(20):
        warshall_list.append(nx.erdos_renyi_graph(20, p))
   
for g in warshall_list:
    m = MyFloydWarshall(g)
    d = nx.floyd_warshall(g)
    n = g.nodes()
    for i in range(len(n)):
        for j in range(i, len(n)):
            my_dist = m[i,j] 
            their_dist = d[n[i]][n[j]]
            if my_dist >= 0:
                assert my_dist == int(their_dist)
            else:
                assert my_dist == -1
                assert their_dist > 20
                
            
 # Question 4
def FindComponentOf(G, v):
   my_nodes = G.nodes()
   #set up an empty dictionary
   d = dict()
   #put a key in it for each node, initially all 0
   for x in my_nodes:
        d[x] = 0
   d[v] = 1
   added = True
   i = 1
   while added:
       added = False
       for x in d.keys():
            if d[x] == i:
                neighbs = G.neighbors(x)
                for y in neighbs:
                    if d[y]==0:
                        d[y] = i+1
                        added = True
       i +=1
   subgraph = []
   for x in d.keys():
        if d[x]> 0:
             subgraph.append(x)
   return G.subgraph(subgraph)
 
def MyConnectedComponents(H) : 
    G = H.copy()
    comps = []
    while G.number_of_nodes() > 0:
        v = G.nodes()[0]
        comp = FindComponentOf(G, v)
        comps.append(comp)
        for n in comp.nodes():
            G.remove_node(n)
    return comps
  
# Let's use some graphs with very low edge probabilities
# so that they have lots of connected components
# plus a smaller number that are probably connected

conn_list = []
for p in [0.02, 0.04, 0.06, 0.08, 0.1, 0.3]:
    for i in range(20):
        conn_list.append(nx.erdos_renyi_graph(20, p))
    
for g in conn_list:
    comps_g = MyConnectedComponents(g)
    assert len(comps_g) == nx.number_connected_components(g)
    
# Question 5

import itertools

def FindClique(G, k):
    node_list = G.nodes()
    goal = k*(k-1)/2
    for x in itertools.combinations(node_list, k):
        s = G.subgraph(x)
        if s.number_of_edges() == goal: #Has maximum possible number
                                        #of edges, so is a clique
            return True, s
    return False, G
    
clique_list = []
for p in [0.2, 0.4, 0.6, 0.8]:
    for i in range(20):
        clique_list.append(nx.erdos_renyi_graph(10, p))

for G in clique_list:
    max_clique = nx.graph_clique_number(G) # Compute the clique number
                                           # only once for each graph
    for k in range(3, 11):
        b, s = FindClique(G,k)
        if not b:
            assert (max_clique < k)
        else:
            assert (s.number_of_nodes() == k)
            assert (s.number_of_edges() == ((k*(k-1))/2))
                                        

clique_times = []
clique_results = []
for i in range(5): # This is slow, so not doing it very many times
    start = time.time()
    g = nx.erdos_renyi_graph(25, 0.5)
    b, s = FindClique(g, 6)
    end = time.time()
    clique_times.append((end-start)*1000)
    clique_results.append(b)
    if not b:
        assert (nx.graph_clique_number(g) < 6)
    else:
        assert (s.number_of_nodes() == 6)
        assert (s.number_of_edges() == 15)              
                                    
# clique_times is [1631.169080734253, 3374.1869926452637, 
# 1010.7908248901367, 2399.756908416748, 1501.8930435180664]
# clique_results is [True, False, True, True, True]

# Notice that we're really slow when there is no clique - lots of sets 
# to check

# Question 6

def FasterFindClique(G, k):
    goal = k*(k-1)/2
    poss = [ ]
    #restrict to only the nodes of degree at least k-1
    for x in G.nodes():
        if G.degree(x) > k-2:
            poss.append(x)
    #also now restrict to those which have at least k-1
    #neighbours in the set of possibles
    changed = True
    while changed:
        changed = False
        to_remove = []
        for x in poss:
            x_neighbs = G.neighbors(x)
            if len(set(x_neighbs) & set(poss)) < (k-1): #& makes intersection
                to_remove.append(x)
                changed = True
        for x in to_remove:
            poss.remove(x)
    for x in itertools.combinations(poss, k):
        s = G.subgraph(x)
        if s.number_of_edges() == goal:
            return True, s
    return False, G
    
faster_clique_times = []
faster_clique_results = []
for i in range(5): # This is slow, so not doing it very many times
    g = nx.erdos_renyi_graph(25, 0.5)
    start = time.time()
    b, s = FasterFindClique(g, 6)
    end = time.time()
    faster_clique_times.append((end-start)*1000)
    faster_clique_results.append(b)
    if not b:
        assert (nx.graph_clique_number(g) < 6)
    else:
        assert (s.number_of_nodes() == 6)
        assert (s.number_of_edges() == 15)              
                                    
# faster_clique_times= [1338.411808013916, 3455.341100692749, 2458.08482170105,
# 178.83586883544922, 3458.096981048584]
# [True, False, True, True, False]
# not actually better! Making a fast clique-finder is actualy quite hard

# Question 7
    
def MyCliqueNumber(G):
   max_d = max(G.degree().values())
   for i in range(1, (max_d+2)):
       b, s = FasterFindClique(G, i)
       if not b:
           return i-1
      
for i in range(len(clique_list)):
    G = clique_list[i]
    max_clique = nx.graph_clique_number(G) # Compute the clique number
                                           # only once for each graph
    my_max_clique = MyCliqueNumber(G)
    assert (max_clique == my_max_clique)
        
# all pass!    
    