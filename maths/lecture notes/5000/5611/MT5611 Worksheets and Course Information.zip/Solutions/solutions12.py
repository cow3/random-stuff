#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Thu Mar  2 10:08:46 2017

@author: cmr1
"""
import networkx as nx

# Question 1
def BasicGreedy(G):
    n = G.number_of_nodes()
    d = dict()
    for x in G.nodes():
        # the following just lets us see whether a node has 
        # been coloured yet. We will never need more colours 
        # than nodes... 
        d[x] = n+1
    names = d.keys()
    d[names[0]] = 0
    for i in range(1, n):
        neighbs = G.neighbors(names[i])
        val_cols = []
        for x in neighbs:
            val_cols.append(d[x])
        val_cols.sort
        j = 0
        while j in val_cols:
            j+=1
        d[names[i]] = j
    return d

 
# Question 2
def CheckColouring(G, d):
    e = G.edges()
    for x in e:
        if (d[x[0]] == d[x[1]]):
            return False
    return True

# Question 3

Ldense = [] #list for the graphs with lots of edges
res_dense = [] #will contain their colourings
for i in range(20):
    g = nx.erdos_renyi_graph(20, 0.6)
    Ldense.append(g)
    res_dense.append(BasicGreedy(g))

Lsparse = [] #list for the graphs with few edges
res_sparse = [] # will contain their colourings
for i in range(20):
    g = nx.erdos_renyi_graph(20, 0.2)
    Lsparse.append(g)
    res_sparse.append(BasicGreedy(g))
    
worked_dense = []
worked_sparse = []
for i in range(20):
    worked_dense.append(CheckColouring(Ldense[i], res_dense[i])) 
    worked_sparse.append(CheckColouring(Lsparse[i], res_sparse[i]))

dense_set = set(worked_dense)
sparse_set = set(worked_sparse)
#dense_set is {True}
#sparse_set is {True}
#so all colourings were correct


def NrColoursUsed(d):
    cols = set(d.values())
    return len(cols)

dense_numbers = []
sparse_numbers = []
for i in range(20):
    c1 = NrColoursUsed(res_dense[i])
    c2 = NrColoursUsed(nx.greedy_color(Ldense[i]))
    dense_numbers.append([c1, c2])
    c1 = NrColoursUsed(res_sparse[i])
    c2 = NrColoursUsed(nx.greedy_color(Lsparse[i]))
    sparse_numbers.append([c1, c2])              
    
# dense_numbers range between 8 and 10 for GreedyColour, and between
# 6 and 9 for nx.greedy_colour. It is clearly better! 

# sparse_numbers range between 3 and 5 for both methods. Sometimes are
# are better than the inbuilt greedy colour (well, once for me) and   
# sometimes we are worse.   
    
# Question 4

def NextToColour(G, d):
    n = G.number_of_nodes()
    coloured = []
    for x in d.keys():
        if d[x] != n+1:
            coloured.append(x)
    for x in coloured:
        ns = G.neighbors(x)
        for y in ns:
            if not y in coloured:
                return y
    return False    

def NeighbourGreedy(G):
    n = G.number_of_nodes()
    d = dict()
    for x in G.nodes():
        # the following just lets us see whether a node has 
        # been coloured yet. We will never need more colours 
        # than nodes... 
        d[x] = n+1
    names = d.keys()
    d[names[0]] = 0
    for i in range(1, n):
        next = NextToColour(G, d)
        y = G.neighbors(next)
        y_cols = []
        for z in y :
            y_cols.append(d[z])
        j = 0
        while j in y_cols:
            j += 1
        d[next] = j
    return d, NrColoursUsed(d)

for i in range(20):
    if nx.is_connected(Lsparse[i]):
       d, c1 = NeighbourGreedy(Lsparse[i])
       assert CheckColouring(Lsparse[i], d)
    else:
        c1 = 21
    sparse_numbers[i].append(c1)
    d, c2 = NeighbourGreedy(Ldense[i])
    assert CheckColouring(Ldense[i], d)
    dense_numbers[i].append(c2)
    
# For the sparse graphs, this is sometimes better and someitmes 
# than both the inbuilt and our own previous greedy functions.
# For the dense graphs, the same is true. There does not seem to be any
# clear pattern, although on average I would say that the inbuilt one 
# is winning


# Question 5

def DegreeNextToColour(G, d):
    n = G.number_of_nodes()
    # First find the currently coloured vertices
    coloured = []
    for x in d.keys():
        if d[x] != n+1:
            coloured.append(x)
    # Now find all of their neighbours that 
    # aren't coloured
    neighbs = []
    for x in coloured:
        for y in G.neighbors(x):
            if not y in coloured:
                neighbs.append(y)
    if len(neighbs) == 0:
        return False # graph is already coloured
    # get rid of repeats
    neighbs = list(set(neighbs))
    max = 0
    res = neighbs[0]
    for i in range(1,len(neighbs)):
        if G.degree(neighbs[i]) > max:
            max = G.degree(neighbs[i])
            res = neighbs[i]
    return res


def DegreeGreedy(G):
    n = G.number_of_nodes()
    d = dict()
    for x in G.nodes():
        # the following just lets us see whether a node has 
        # been coloured yet. We will never need more colours 
        # than nodes... 
        d[x] = n+1
    names = d.keys()
    degs = G.degree()
    max_deg = max(degs.values())
    i = 0
    while (degs[names[i]] < max_deg):
        i = i+1
    d[i] = 0
    for i in xrange(1,n):
        next = DegreeNextToColour(G, d)
        neighbs = G.neighbors(next)
        next_cols = []
        for x in neighbs:
            next_cols.append(d[x])
        j = 0
        while j in next_cols:
            j += 1
        d[next] = j
    return d, NrColoursUsed(d)
    
for i in range(20):
    if nx.is_connected(Lsparse[i]):
        d, c1 = DegreeGreedy(Lsparse[i])
        assert CheckColouring(Lsparse[i], d)
    else:
        c1 = 21                    
    sparse_numbers[i].append(c1)
    d, c2 = DegreeGreedy(Ldense[i])
    assert CheckColouring(Ldense[i], d)
    dense_numbers[i].append(c2)

# This one actually seems to be quite good. For me, this is now  
# only occasionally doing worse than the inbuilt function, and is 
# sometimes doing better than it.
# For the sparse graphs, it someitmes isn't working though.


# Question 6

import itertools

def ColourInOrder(G, nds):
    n = G.number_of_nodes()
    d = dict()
    for x in nds:
        d[x] = n+1
    for x in nds:
        neighbs = G.neighbors(x)
        neighb_colours = []
        for y in neighbs:
            neighb_colours.append(d[y])
        j = 0
        while j in neighb_colours:
            j+= 1
        d[x] = j
    return d, NrColoursUsed(d)
        
def GreedyChromatic(G):
    nds = G.nodes()
    best_size = len(nds)
    for x in itertools.permutations(nds):
        colouring, size = ColourInOrder(G, nds)
        if size <= best_size:
            best_size = size
            best_colouring = colouring
    return best_colouring, best_size
  
import time

fives = []
for i in range(20):
    fives.append(nx.erdos_renyi_graph(5, 0.5))

five_chroms = []
five_times = []
for g in fives:
    start = time.time()
    d, c = GreedyChromatic(g)
    end = time.time()
    assert CheckColouring(g, d)
    five_chroms.append(c)
    five_times.append((end - start)*1000)
                   
# One took more than a millisecnd but rest were quicker

sixes = []
for i in range(20):
    sixes.append(nx.erdos_renyi_graph(6, 0.5))

six_chroms = []
six_times = []
for g in sixes:
    start = time.time()
    d, c = GreedyChromatic(g)
    end = time.time()
    assert CheckColouring(g, d)
    six_chroms.append(c)
    six_times.append((end - start)*1000)
                   
# 5 to 7 milliseconds

sevens = []
for i in range(20):
    sevens.append(nx.erdos_renyi_graph(7, 0.5))

sevens_chroms = []
sevens_times = []
for g in sevens:
    start = time.time()
    d, c = GreedyChromatic(g)
    end = time.time()
    assert CheckColouring(g, d)
    sevens_chroms.append(c)
    sevens_times.append((end - start)*1000)
                   
# 45 to 65 milliseconds

eights = []
for i in range(20):
    eights.append(nx.erdos_renyi_graph(8, 0.5))

eights_chroms = []
eights_times = []
for g in eights:
    start = time.time()
    d, c = GreedyChromatic(g)
    end = time.time()
    assert CheckColouring(g, d)
    eights_chroms.append(c)
    eights_times.append((end - start)*1000)

# 400 to 600 milliseconds!

# Next one is commented out as makes worksheet run 
# very slowly, uncomment if you want to see the times.

nines = []
for i in range(20):
    nines.append(nx.erdos_renyi_graph(9, 0.5))

nines_chroms = []
nines_times = []
#for g in nines:
#    d, c = GreedyChromatic(g)
#    start = time.time()
#    end = time.time()
#    assert CheckColouring(g, d)
#    nines_chroms.append(c)
#    nines_times.append((end - start)*1000)

# 5000 to 6500 milliseconds!

   
# Question 7

def FasterGreedyChromatic(G):
    k = nx.graph_clique_number(G)
    nds = G.nodes()
    best_size = len(nds)
    for x in itertools.permutations(nds):
        colouring, size = ColourInOrder(G, nds)
        if size <= best_size:
            best_size = size
            best_colouring = colouring
            if size == k:
                return best_colouring, best_size
    return best_colouring, best_size
  

faster_eights_times = []
for i in xrange(20):
    start = time.time()
    d, c = FasterGreedyChromatic(eights[i])
    end = time.time()
    assert c == eights_chroms[i]
    faster_eights_times.append((end - start)*1000)

# Dramatically faster in most cases, although the very 
#worst cases are still as slow