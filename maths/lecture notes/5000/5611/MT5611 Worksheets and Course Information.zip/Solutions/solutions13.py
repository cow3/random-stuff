# These are the solutions to the problems on Sheet 13


import networkx as nx
import itertools as iter

# Question 1(a)

def CheckColouringSolution(G, k, L):
    assert isinstance(L, list)
    for x in L:
        assert (0 <= x) and (x < k)
    verts = G.nodes()
    if len(L) < len(verts):
        return False
    edg = G.edges()
    for e in edg:
        p1 = verts.index(e[0])
        p2 = verts.index(e[1])
        if L[p1]==L[p2]:
            return False
    return True
    
# Question 1(b)

def ExhaustiveColouring(G, k):
    n = G.number_of_nodes()
    colours = range(k)
    m = iter.product(colours, repeat = n)
    for x in m:
        if CheckColouringSolution(G, k, list(x)):
            return True, list(x)
    return False, []
    
# Question 1(c)

def ExhaustiveChromatic(G):
    n = G.number_of_nodes()
    for k in range(1, n+1):
        if ExhaustiveColouring(G, k):
            return k
 
# Question 2(a)
    
def CheckPartialColouring(G, k, L):
    assert isinstance(L, list)
    for x in L:
        assert (0 <= x) and (x < k)
    verts = G.nodes()
    edg = G.edges()
    n = len(L)
    for e in edg:
        p1 = verts.index(e[0])
        p2 = verts.index(e[1])
        if (p1 < n) and (p2 < n):
            if L[p1] == L[p2]:
                return False
    return True


# Question 2(b)

def ColourExtending(G, k, L):
    assert isinstance(L, list)
    for x in L:
        assert (0 <= x) and (x<k)
    if CheckColouringSolution(G, k, L):
        return True, L
    if not CheckPartialColouring(G, k, L):
        return False, []
    for i in range(k):
        M = L + [i]
        b, L1 = ColourExtending(G, k, M)
        if b:
            return True, L1
    return False, []
        

# Question 2(c)

def BacktrackColour(G, k):
    b, L = ColourExtending(G, k, [0])
    d = dict()
    if b == False:
        return False, d
    verts = G.nodes()
    for i in range(len(verts)):
        d[verts[i]] = L[i]
    return True, d

graphs= [];
for n in [5, 6, 7, 8]:
    for p in [0.2, 0.5, 0.8]:
        for i in range(1, 10):
            graphs.append(nx.erdos_renyi_graph(n, p))
 
import time

times_exhaustive = []
times_backtrack = []
colours_res = [[], []]
for k in range(2, 7):
    print "testing for ", k, "colourings"
    k_res = []
    times_exhaustive.append(0)
    times_backtrack.append(0)
    for x in graphs:
        start = time.time()
        b1, L1 = ExhaustiveColouring(x, k)
        end = time.time()
        times_exhaustive[-1] += ((end - start)*1000)
        start = time.time()
        b2, L2 = BacktrackColour(x, k)
        end = time.time()
        times_backtrack[-1] += ((end - start)*1000)
        assert b1 == b2
        k_res.append(b2)
    colours_res.append(k_res)    

#times_exhaustive - [95.58749198913574, 1358.825445175171, 8232.062816619873,
# 16452.027559280396, 8811.228275299072]

#times_backtrack - [20.623445510864258, 42.23918914794922, 91.44163131713867,
# 132.08246231079102, 23.76866340637207]

# the backtrack is dramatically quicker
        
# Question 2(d)

def Chromatic(G):
    d = nx.greedy_color(G)
    k = len(set(d.values()))
    succeed = True
    while ((k > 1) and succeed):
        succeed, colouring = BacktrackColour(G, k-1)
        if succeed:
           k = k - 1
    return k

chromatic_times = []
chromatic_numbers = []
for x in graphs:
    start = time.time()
    k = Chromatic(x)
    end = time.time()
    chromatic_times.append((end - start)*1000)
    chromatic_numbers.append(k)
    
for i in range(len(graphs)):
    k = chromatic_numbers[i]
    for j in range(2, k):
        assert not colours_res[j][i] 
    for j in range(k,7):
        if j > 1:
           assert colours_res[j][i]
    
    
