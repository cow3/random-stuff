import requests
r = requests.get('http://theran.lt/assets/2017/MT4111/word.txt')
word = r.text[:100000]



# Ex 1
def rot(w,k):
    return w[k:] + w[:k]
    
# Ex 2
def all_rots(w):
    return [rot(w,k) for k in range(len(w))]

# Not required, used for testing
def is_lyndon(w):
    rs = all_rots(w)
    rs.sort()
    n = len(rs)
    
    if n == 1:
        return True
    else:
        return w == rs[0] and w < rs[1]

# Ex 3        
def min_rotation_naive(w):
    return min(all_rots(w))

#Ex 4 (see PDF)
def greedy_combine(F,i=0):
    """
    Given an input list F of Lyndon words, greedily
    build a longer Lyndon word from position i.
    
    x is the word we are building
    i is a position in F to start
    
    the return values are x, position where we
    couldn't continue growing x
    """
    n = len(F)
    
    if n == 1:
        return F[0],1
    else:
        x = F[i]
        i = i + 1
        while i < n and F[i] > x:
            x += F[i]
            i = i + 1
        return x, i

def greedy_pass(F):
    """
    Given an input list F of Lyndon words, make it 
    closer to lex non-increasing by greedily combining 
    out-of order runs
    """
    n = len(F)
    i = 0
    Fprime = list()
    
    while i < n:
        x,j = greedy_combine(F,i)
        Fprime.append(x)
        i = j
        
    return Fprime
    
def cfl_naive(w):
    """
    Compute the CFL factors by greedily combining
    until the process stabilizes 
    """
    F = list(w)
    Fprime = greedy_pass(F)
    
    while len(Fprime) < len(F):
        F = Fprime
        Fprime = greedy_pass(F)
        
    return Fprime
    
def cfl_naive(w):
    factors = list(w)
    
    didsomething = True
    
    while didsomething:
        didsomething = False
        
        m = len(factors)
        f = list()
        x = factors[0]
        
        for i in range(1,m):
            if factors[i] > x:
                x += factors[i]
                didsomething = True
            else:
                f.append(x)
                x = factors[i]
        f.append(x)
        factors = f
        
    return factors

# Ex 5 (see PDF)
def run_extend_from(w,x,i):
    """
    w is the string were are reading
    x is a Lyndon word
    i is where to start reading
    
    return the word we found as the first value
    
    the second value is:
    
    0 if we found a copy of x
    1 if we found a Lyndon word bigger than x
    2 otherwise 
    """
    n = len(w)
    m = len(x)
    j = i
    k = 0
    
    while j < n and k < m and w[j] == x[k]:
        j = j + 1
        k = k + 1
    
    if j == n and k < m:
        # fell of the end of w with a prefix of x
        # this is always case 2
        return 'junk', 2
    
    if k == m:
        # found a copy of x
        return w[i:j], 0
    elif w[j] > x[k]:
        # found a Lyndon word bigger than x
        # greedily extend and return
        j = j + 1
        while j < n and w[j] > w[j-1]:
            j = j + 1
            
        return w[i:j],1
    else:
        return 'junk',2
            

def initial_factors(w,k=0):
    """
    Returns a list of the leading CFL factors of 
    w and the place to continue reading (as the 
    2nd value)
    
    k is where to start reading from
    """
    n = len(w)
    i = k + 1
    run = [ w[k] ]
    
    while True:
        x,stat = run_extend_from(w,run[0],i)
        
        if stat == 2:
            # the current run consists of CFL factors
            return run, len(run)*len(run[0])
        elif stat == 1:
            # the current run collapses
            run = [''.join(run) + x]
            i = i + len(x)
        else:
            # extend the current run
            run.append(x)
            i = i + len(x)
        
        assert i <= n
        
        if i == n:
            return run, len(run)*len(run[0])
            
def cfl(w):
    n = len(w)
    i = 0
    factors = list()
    
    while i < n:
        f,l = initial_factors(w,i)
        factors += f
        i = i + l
    
    assert i == n
    return factors
        
# Ex 6
def min_rotation_u(w):
    n = len(w)
    factors = cfl(2*w)
    
    for f in factors:
        if len(f) == n:
            return f

# Ex 7
def convert_runs(L):
    rv = list()
    n = len(L)
    
    if n == 0:
        return L
    else:
        current = L[0]
        count = 1
        for i in range(1,n - 1):
            if L[i] == current:
                count = count + 1
            else:
                rv.append((current,count))
                current = L[i]
                count = 1
                
        if L[n - 1] == current:
            rv.append((current,count + 1))
        else:
            rv.append((current,count))
            rv.append((L[n-1],1))
            
        return rv
       
def min_rotation(w):
    n = len(w)
    factors = convert_runs(cfl(2*w))
    
    for f,l in factors:
        k = len(f)
        
        if n % k == 0 and k*l >= n:
            return (n/k) * f