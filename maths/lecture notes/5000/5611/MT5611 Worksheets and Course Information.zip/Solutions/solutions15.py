import math as mm
import fractions as ff

# memoize decorator from notes
import functools as ft
def memoize(f):
    memo = dict()
    @ft.wraps(f)
    def wrapper(*args):
        if args in memo:
            return memo[args]
        else:
            rv = f(*args)
            memo[args] = rv
            return rv
    return wrapper
    
# useful helper functions
def frac(n,d):
    return ff.Fraction(n,d)
    
def fact(n):
    return mm.factorial(n)
    
def binom(n,k):
    return fact(n)/(fact(k)*fact(n-k))
    
#Q1

def I_q1(m,n):
    return fact(m)*binom(n,m)
    
def birthday_q1(m,n):
    return 1 - frac(1,n**m)*I(m,n)
    
#Q2

# this will solve the more general problem
@memoize
def I(k,m,n):
    def t(c):
        pf = 1
        for j in range(c):
            pf *= binom(m - k*j,k)
        return frac(1,fact(c))*pf
        
    if k == 1:
        return fact(m)*binom(n,m)
    else:
        rv = 0
        for c in range(m/k + 1):
            # note that I(1,c,n)*I(1,m - 2*c,n - c) = I(1,m - c,n)
            # so (4) is a special case of this formula
            rv += t(c)*I(1,c,n)*I(k - 1,m - c*k,n - c)
            
        return rv
        
def birthday(k,m,n):
    return 1 - frac(1,n**m)*I(k-1,m,n)
    
#Q3

def find_b3_median(n):
    i = 0
    while birthday(3,i,n) < frac(1,2):
        i = i + 1
    return i

# >>> find_b3_median(365)
# 88

#Q4
def all_maps(m,n):
    """Returns a list of all maps from [m] to [n]"""
    assert n > 0 and m > 0
    
    if m == 1:
        return [[i] for i in range(n)]
    else:
        T0 = all_maps(m - 1,n)
        T = []
        for j in range(n):
            T = T + append_all(T0,j)
        
        return T

def append_all(L,x):
    """Returns a list with every element of L having x appended to it."""
    # nb. avoid modifying t
    return [t + [x] for t in L]

# histogram function from the lecture notes
from collections import defaultdict

def histogram(l):
    h = defaultdict(int)
    for x in l:
        h[x] = h[x] + 1
    return h
    
def almost_inj(k,m):
    return max(histogram(m).values()) <= k
    
def exhausting_birthday(k,m,n):
    return 1 - frac(1,n**m)*len([m for m in all_maps(m,n) if almost_inj(k-1,m)])
    
# >>> exhausting_birthday(2,5,7) == birthday(2,5,7)
# True
    
#Q5
def find_b4_median(n):
    i = 0
    while birthday(4,i,n) < frac(1,2):
        i = i + 1
    return i

#>>> find_b4_median(365)
#187

    