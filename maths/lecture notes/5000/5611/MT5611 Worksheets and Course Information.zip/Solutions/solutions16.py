# Q1

## can read this as "one there is a b, no more a's"
r1 = r'[^b]*[^a]*$'

'''
Example:

>>> r1 = r'[^b]*[^a]*$'
>>> re.match(r1,'advfdgfdgdfsaaaavvvvbgfdsfbbdfds')
<_sre.SRE_Match object; span=(0, 32), match='advfdgfdgdfsaaaavvvvbgfdsfbbdfds'>
>>> re.match(r1,'advfdgfdgdfsaaaavvvvbgfdsfabbdfds')
'''

# Q2

## the idea is that a's come in pairs, or groups of 5

r2 = r'(([^a]*a[^a]*a)+|([^a]*a[^a]*a[^a]*a[^a]*a[^a]*a)*)$' 

'''
Examples:

>>> r2 = r'(([^a]*a[^a]*a)+|([^a]*a[^a]*a[^a]*a[^a]*a[^a]*a)*)$' 
>>> re.match(r2,'aaa')
>>> re.match(r2,'')
<_sre.SRE_Match object; span=(0, 0), match=''>
>>> re.match(r2,'abdjfdfadfdfdsdadfdsfdsa')
<_sre.SRE_Match object; span=(0, 24), match='abdjfdfadfdfdsdadfdsfdsa'>
>>> re.match(r2,'aaaaa')
<_sre.SRE_Match object; span=(0, 5), match='aaaaa'>
>>> re.match(r2,'aaaaaaa')
>>> re.match(r2,'aaaaaaaaa')
>>> re.match(r2,'aaaaaaaaaa')
<_sre.SRE_Match object; span=(0, 10), match='aaaaaaaaaa'>
'''

# Q3

r3 = r'[a-zA-z][-.a-zA-Z0-9]*([+][-.a-zA-Z0-9]*)?@([a-zA-Z][-a-zA-Z0-9]*[.])+[a-zA-Z][-a-zA-Z0-9]*'

'''
Examples:

>>> r3 = r'[a-zA-z][-.a-zA-Z0-9]*([+][-.a-zA-Z0-9]*)?@([a-zA-Z][-a-zA-Z0-9]*[.])+[a-zA-Z][-a-zA-Z0-9]*'
>>> re.match(r3,'lst6@st-andrews.ac.uk')
<_sre.SRE_Match object; span=(0, 21), match='lst6@st-andrews.ac.uk'>
>>> re.match(r3,'lst6-testing+MT4111@st-andrews1.ac.uk')
<_sre.SRE_Match object; span=(0, 37), match='lst6-testing+MT4111@st-andrews1.ac.uk'>
>>> re.match(r3,'lst6-testing+MT4111+xyz@st-andrews1.ac.uk')
>>> re.match(r3,'lst6-testing+MT4111@$t-andrews1.ac.uk')
'''

# Q4
r4 = r'(([a-zA-z][-.a-zA-Z0-9]*([+][-.a-zA-Z0-9]*)?)@(([a-zA-Z][-a-zA-Z0-9]*[.])+[a-zA-Z][-a-zA-Z0-9]*))'

directory = '''
Dr Louis Theran	Lecturer	328 MI	01334 463807	louis.theran@st-andrews.ac.uk
Dr Len Thomas	Reader	130 OB	01334 461801	len.thomas@st-andrews.ac.uk
Dr James Threlfall	Research Fellow	217 MI	01334 461647	jwt9@st-andrews.ac.uk
Dr Mike Todd	Reader	320 MI	01334 463701	m.todd@st-andrews.ac.uk
Dr Chuong Tran	Lecturer	306 MI	01334 463741	cvt1@st-andrews.ac.uk
V
name	position	room no.	telephone	email
Dr Chandrasekhar Venkataraman	Lecturer in Mathematical Biology	310 MI	01334 463740	cv28@st-andrews.ac.uk
W
name	position	room no.	telephone	email
Ms Tricia Watson	Secretary	202 MI	01334 463747	Tricia.Watson@st-andrews.ac.uk
Dr Antonia Wilmot-Smith	Teaching Fellow	331 MI	01334 463228	aw37@st-andrews.ac.uk
Dr Fiona Wilson	Research Fellow	217 MI	01334 461647	fw237@st-andrews.ac.uk
Miss Hannah Worthington	Teaching Fellow	106 OB	01334 461806	hw233@st-andrews.ac.uk
Dr Andrew Wright	Reader	212 MI	01334 463736	anw@st-andrews.ac.uk
Y
name	position	room no.	telephone	email
Miss Stephanie Yardley	Research Fellow	307 MI		sly3@st-andrews.ac.uk
Dr Joyce Yuan	Research Fellow	209 OB	01334 461826	yy84@st-andrews.ac.uk
School of Mathematics & Statistics
University of St Andrews
St Andrews
KY16 9SS
01334 463744
maths@st-andrews.ac.uk
Research groups
Algebra and Combinatorics
Analysis
Mathematical Biology
SMTG
Statistical Ecology
Statistical Inference
Vortex Dynamics
Interdisciplinary Centres
CIRCA
CREEM
SOI
Resources
MMS
Staff Area
MacTutor History of Mathematics Archive
© 2017 The University of St Andrews is a charity registered in Scotland, No SC013532 Edit
'''

def emails(s):
    matches = re.findall(r4,s)
    return [m[0] for m in matches]
    
'''
Example:
    
>>> emails(directory)
['louis.theran@st-andrews.ac.uk', 'len.thomas@st-andrews.ac.uk', 'jwt9@st-andrews.ac.uk', 'm.todd@st-andrews.ac.uk', 'cvt1@st-andrews.ac.uk', 'cv28@st-andrews.ac.uk', 'Tricia.Watson@st-andrews.ac.uk', 'aw37@st-andrews.ac.uk', 'fw237@st-andrews.ac.uk', 'hw233@st-andrews.ac.uk', 'anw@st-andrews.ac.uk', 'MIsly3@st-andrews.ac.uk', 'yy84@st-andrews.ac.uk', 'maths@st-andrews.ac.uk']
   
'''
    
# Q5

def email_pairs(s):
    matches = re.findall(r4,s)
    return [(m[1], m[3]) for m in matches]
    
'''
Example:
    
>>> email_pairs(directory)
[('louis.theran', 'st-andrews.ac.uk'), ('len.thomas', 'st-andrews.ac.uk'), ('jwt9', 'st-andrews.ac.uk'), ('m.todd', 'st-andrews.ac.uk'), ('cvt1', 'st-andrews.ac.uk'), ('cv28', 'st-andrews.ac.uk'), ('Tricia.Watson', 'st-andrews.ac.uk'), ('aw37', 'st-andrews.ac.uk'), ('fw237', 'st-andrews.ac.uk'), ('hw233', 'st-andrews.ac.uk'), ('anw', 'st-andrews.ac.uk'), ('MIsly3', 'st-andrews.ac.uk'), ('yy84', 'st-andrews.ac.uk'), ('maths', 'st-andrews.ac.uk')]    
'''
    
# Q6

latex = '''  
\includegraphics{filename.ext}
\includegraphics[width={4 in}]{filename.ext}
  \includegraphics[width={3 in},height={2 in}]{filename.ext}'''
  
r5 = r'\\includegraphics(\[[^\]]+\])?\{(\w+)([.]\w+)?\}'

def figure_filenames(s):
    return [m[1] for m in re.findall(r5,s)]
    
'''
Examples:
    
>>> figure_filenames(latex)
['filename', 'filename', 'filename']    
'''
    
# Q7

good = '''abba
anallagmatic
bassarisk
chorioallantois
coccomyces
commotive
engrammatic'''

bad = '''acritan
aesthophysiology
amphimictical
baruria
calomorphic
disarmature
effusive'''

r6 = r'(.)(.)\2\1'

'''
It works!

>>> re.findall(r6,good)
[('a', 'b'), ('a', 'l'), ('a', 's'), ('a', 'l'), ('o', 'c'), ('o', 'm'), ('a', 'm')]
>>> re.findall(r6,bad)
[]
'''
