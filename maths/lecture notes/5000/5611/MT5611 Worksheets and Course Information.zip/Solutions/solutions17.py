import numpy as np
import scipy.linalg as la

# Q2

'''
Setting shape changes the shape.  Reshape is a new matrix object
with the desired shape.
'''

# Q3
def pdet(A,eps=0.000001):
    L,_ = la.eig(A)
    return np.prod(L[abs(L)>eps])
    
# Q4

def kn_laplacian(n):
    K = -np.ones((n,n))
    # shortcut to avoid making Delta
    np.fill_diagonal(K,n - 1)
    return K
    
def kn_kirchoff(n):
    # annoying cast to float to extract the real part
    pd = np.float_(pdet(kn_laplacian(n)))
    return pd / n

'''
Trying this on a few values:
    >>> [kn_kirchoff(n) for n in [3,4,5]]
    [2.9999999999999996, 15.999999999999991, 125.00000000000009]
    
We could guess that the answer is n^(n-2)
'''

# Q5

def find_evec(A,eps=0.00001):
    m,n = A.shape
    
    x = np.mat(np.random.randn(n,1))
    x = x / la.norm(x)
    xx = A*x
    xx = xx / la.norm(xx)
    
    while la.norm(x - xx) > eps:
        x = xx
        xx = A*x
        xx = xx / la.norm(xx)
        
    return xx
    
'''
Small example:

>>> M = np.mat([[1,1],[1,0]])
>>> ev = find_evec(M)
>>> x = M*ev
>>> x = (1/la.norm(x))*x
>>> ev
matrix([[-0.85065019],
        [-0.52573211]])
>>> x
matrix([[-0.85065104],
        [-0.52573073]])
    

Bigger example:

>>> L = kn_laplacian(100)
>>> ev = find_evec(L,0.000000001)
>>> x = L*ev
>>> x = (1/la.norm(x))*x
>>> np.max(x - ev)
5.5511151231257827e-17
    
This converges really fast.  (For reasons we'll see 
soon.)
'''
    
# Q6

'''
>>> [((M**k)*np.mat([[1],[1]])).T for k in [1,2,3,4,5]]
[matrix([[2, 1]]), matrix([[3, 2]]), matrix([[5, 3]]), matrix([[8, 5]]), matrix([[13,  8]])]

The thing to notice is that these are just the (k+2)th and (k+1)st 
Fibonacci numbers.  Since this sequence converges to an eigenvector,
its direction vector convergest to (r,1), where r is the asymptotic 
ratio between Fibonacci numbers.
'''

# Q7

def energy(A,v):
    x = v.T*A*v
    return np.asscalar(x) / la.norm(v)**2
    
# Q8

'''
>>> energy(M,ev)
1.6180339887468131
>>> (1/2)*(1 + np.sqrt(2))
1.2071067811865475
>>> (1/2)*(1 + np.sqrt(5))
1.6180339887498949

The claim checks out numerically.  As we computed above, 
after a while M^k (1,1)^t is approximately (r^k r^k-1)^T
and also two sequential Fibonacci numbers.  Thus the 
coarse growth of the Fibonacci numbers is like r^k and 
r is the golden ratio.

(If you want to prove this, notice that the energy of 
(r 1) is r.  Write this explicitly and solve for r.)
'''