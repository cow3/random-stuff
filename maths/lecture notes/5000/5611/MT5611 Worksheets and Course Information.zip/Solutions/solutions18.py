import numpy as np

# Q2

def shuffle_columns(A):
    m,n = A.shape
    return A[:,np.random.permutation(n)]
    
# Q3

# modifies and returns its argument
def chop(A,eps=0.000001):
    A[abs(A)<eps] = 0
    return A
    
# Q4

def rand_01(m,n,p):
    A = np.random.random((m,n))
    chop(A,1-p)
    A[A>0] = 1
    return np.mat(A)
    
# Q5

def rand_bipartite(m,n,p):
    X = rand_01(m,n,p)
    return np.bmat(
        [[np.zeros((m,n)), X],[X.T, np.zeros((n,m))]] )

# Q6

def deg_cols(A):
    m,n = A.shape
    degs = np.sum(A,0)
    return np.tile(degs,(m,1))
    
# Q7

# works using element-wise product on the boolean 
# matrices
def has_triangle(A):
    return np.any(np.multiply(A>0,A*A>0))
    
# this is much much slower.  I didn't bother
# to let it finish on an example with 1000
# vertices, which the other one handles instantly
def naive_triangle(A):
    n,_ = A.shape
    
    for i in range(n):
        for j in range(i+1,n):
            for k in range(j+1,n):
                if A[i,j] and A[i,k] and A[j,k]:
                    return True
    return False