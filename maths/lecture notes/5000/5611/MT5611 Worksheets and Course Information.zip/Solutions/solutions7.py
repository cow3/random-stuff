#!/usr/bin/env python2
# -*- coding: utf-8 -*-

# These are model solutions to the questions from CMRD's first worksheet
# 11/02/2017

import random, copy

# Problem 1

# This function takes a list as input, and returns a copy
# of the list that has been randomly shuffled.
def permuteList(L):
    assert isinstance(L, list)
    res = []
    new_list = copy.copy(L)
    for i in xrange(len(L)):
        next_choice = random.choice(new_list)
        res.append(next_choice)
        new_list.remove(next_choice)
    return res
    
L_1 = range(1,11)
L_1_shuffled = permuteList(L_1)   
# L_1 = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
# L_1_shuffled = [1, 7, 2, 10, 3, 6, 9, 4, 5, 8] (for me, yours may differ)

L_2 = range(1, 31)
L_2_shuffled= permuteList(L_2)
#L_2 = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15,
# 16, 17, 18, 19, 20, 21, 22, 22, 23, 24, 25, 26, 27, 28, 29, 30]
#L_22 = [10, 16, 8, 24, 15, 12, 11, 2, 22, 5, 6, 29, 7, 30, 25, 19,
# 28, 17, 14, 26, 27, 1, 4, 18, 13, 23, 20, 21, 3, 9] (for me, yours 
# may differ)

# we find the integer part of the square root of 1000
top = int(1000**0.5)        
# we make a list containing all square of numbers from 1 up to top 
squares = []
for i in range(1, top+1):
    squares.append(i**2)

# now we shuffle the list of squares
squares_shuffled = permuteList(squares)    

# squares is now [1, 4, 9, 16, 25, 36, 49, 64, 81, 100, 121, 144, 169,
# 196, 225, 256, 289, 324, 361, 400, 441, 484, 529, 576, 625, 676,
# 729, 784, 841, 900, 961]

# for me, squares_shuffled = [81, 9, 900, 441, 64, 324, 225, 144, 784,
# 576, 169, 400, 484, 121, 100, 529, 16, 361, 729, 4, 1, 625, 289,
# 36, 256, 961, 676, 25, 196, 841, 49]

# Problem 2

deck = []
for x in ["S", "H", "D", "C"]:
    for i in range(1,11) + ["J", "Q", "K"]:
        deck.append((x, i))
        
deck_shuffled = permuteList(deck)

# deck is [('S', 1), ('S', 2), ('S', 3), ('S', 4), ('S', 5), ('S', 6),
# ('S', 7), ('S', 8), ('S', 9), ('S', 10), ('S', 'J'), ('S', 'Q'),
# ('S', 'K'), ('H', 1), ('H', 2), ('H', 3), ('H', 4), ('H', 5),
# ('H', 6), ('H', 7), ('H', 8), ('H', 9), ('H', 10), ('H', 'J'),
# ('H', 'Q'), ('H', 'K'), ('D', 1), ('D', 2), ('D', 3), ('D', 4),
# ('D', 5), ('D', 6), ('D', 7), ('D', 8), ('D', 9), ('D', 10),
# ('D', 'J'), ('D', 'Q'), ('D', 'K'), ('C', 1), ('C', 2), ('C', 3),
# ('C', 4), ('C', 5), ('C', 6), ('C', 7), ('C', 8), ('C', 9),
# ('C', 10), ('C', 'J'), ('C', 'Q'), ('C', 'K')]

# for me, deck_shuffled is [('S', 9), ('C', 'Q'), ('H', 'J'), ('D', 2),
# ('H', 5), ('H', 'K'), ('S', 'Q'), ('S', 10), ('C', 'J'), ('S', 1),
# ('S', 5), ('D', 7), ('D', 'J'), ('H', 9), ('C', 9), ('D', 9), ('D', 8),
# ('H', 3), ('C', 5), ('D', 1), ('S', 4), ('C', 8), ('D', 4), ('S', 'K'),
# ('D', 'K'), ('C', 6), ('H', 6), ('C', 7), ('D', 5), ('S', 6), ('S', 3),
# ('D', 6), ('C', 10), ('C', 1), ('D', 10), ('D', 3), ('H', 10), ('H', 8),
# ('H', 4), ('S', 'J'), ('H', 'Q'), ('S', 8), ('H', 1), ('D', 'Q'), ('C', 2),
# ('S', 7), ('C', 4), ('C', 3), ('H', 2), ('C', 'K'), ('S', 2), ('H', 7)]

# Problem 3

# The following function takes as input a list L, of objects for which 
# > is defined. It uses bubble sort to sort a copy of the list, and whilst
# doing so it counts the number of comparisons that it makes. It returns 
# the sorted copy of the list, and the total number of comparisons.
def BubbleSortCount(L):
    assert isinstance(L, list)
    n = len(L)
    answer = copy.copy(L)
    comp_total = 0
    for i in range(n):
       for j in range(n-i-1):
           comp_total += 1
           if answer[j] > answer[j+1]:
               z = answer[j]
               answer[j] = answer[j+1]
               answer[j+1] = z
    return answer, comp_total   

res_five = []    
for i in range(3):  
   L = permuteList(range(1,6))    
   res_five.append(BubbleSortCount(L)[1])
   
# res_five is [10, 10, 10]  
# always count 10 comparisons for a list of length 5.
# 10 = 4+3+2+1
 
res_ten = [] 
for i in range(3):    
   L = permuteList(range(1,11))    
   res_ten.append(BubbleSortCount(L)[1])

# res_ten is [45, 45, 45]
#always count 45 comparisons   
# 45 = 9 + 8 + ... + 1.

res_fifteen = []
for i in range(3):   
   L = permuteList(range(1,16))    
   res_fifteen.append(BubbleSortCount(L)[1])

# res_fifteen is [105, 105, 105]
# always count 105 comparisons

final_test = BubbleSortCount(range(1, 11))[1]

# final_test is 45 comparisons

# For all lists of length n, we always do n(n-1)/2 comparisons, 
# This is because we do (n-1) comparisons in the first pass
# (n-2) comparisons in the second, (n-3) in the third, and so on.
# 1+2+ .. + (n-1) = n(n-1)/2
  
# Problem 4

# Following function takes as input a list L. It sorts a copy of 
# L using a version of bubble sort that stops early when a complete
# pass occurs with no swaps. It returns the sorted copy of L, together
# with the total number of swaps, and the total number of comparisons.

def BubbleSortQuicker(L):
    assert isinstance(L, list)
    n = len(L)
    answer = copy.copy(L)
    comp_total = 0 # counts total number of comparisons
    swap_count = 1 # counts number of swaps in current pass. Set to
    # 1 initially to make sure that we start the sort.
    swap_total = 0 # counts total number of swaps
    for i in range(n):
        if swap_count > 0: # test whether made swaps in previous pass
            swap_count = 0 # reset number of swaps to 0 for this pass.
            for j in range(n-i-1):
                comp_total += 1
                if answer[j] > answer[j+1]:
                    z = answer[j]
                    answer[j] = answer[j+1]
                    answer[j+1] = z
                    swap_count += 1
        swap_total += swap_count
    return answer, swap_total, comp_total
    
    
range_sorted, swaps_range, comp_range = BubbleSortQuicker(range(1,11))    
# range_sorted is [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
# swaps_range is 0 : we made no swaps
# comp_range is 9 : this is the number of comparisons in the first pass,
# as we stop after that
                 
five_back, swaps_five, comps_five = BubbleSortQuicker(range(5, 0, -1))  
# five_back =  [1, 2, 3, 4, 5] 
# swaps_five = 10
# comps_five = 10

ten_back, swaps_ten, comps_ten = BubbleSortQuicker(range(10, 0, -1))
# ten_back =  [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
# swaps_ten = 45
# comps_ten = 45

fifteen_back, swaps_fifteen, comps_fifteen = BubbleSortQuicker(range(15, 0, -1))
# fifteen_back = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15] 
# swaps_ten = 105
# comps_ten = 105

# These counts are the same as for BubbleSortCount: every time
# we do a comparison we make a swap, so n(n-1)/2 comparisons
# and n(n-1)/2 swaps


# Problem 5

# set up two empty lists with entries from 0 to 45, as 45 is the maximum 
# possible number of swaps and comparisons for a list of length 10
swap_data = []
comp_data = []
for i in range(46):
    swap_data.append(0)
    comp_data.append(0)
    
#100 times we make a random list and sort it
# c will be a triple of the sorted list, the number of swaps
# and the number of comparisons    
for i in xrange(100):
    L = permuteList(range(1, 11))
    c= BubbleSortQuicker(L)
    swap_data[c[1]] = swap_data[c[1]] + 1
    comp_data[c[2]] = comp_data[c[2]] + 1

#swap_data and count_data are now the number of times each count
# of swaps and comparisons occurs
import matplotlib.pyplot as plt

chart1 = plt.bar(range(46), swap_data, 1, color = "blue")
plt.show()

# the number of swaps forms roughly a bell curve, with the minimum
# (for me) at about 10 and teh maximum at about 37. 
# most of them are in the range 19-30 with a peak in the
# mid-20s

chart = plt.bar(range(46), comp_data, 1, color = "red")
plt.show()

# the number of comparisons is much clumpier, as the passes 
# come in fixed sizes. For me, the single most common occurrence is to 
# make the maximum number of comparisons: 45. After that comes 
# stopping two passes before the end: 42, and stopping only 
# one pass early: 43.
# so whilst BubbleSortQuicker is quite a bit quicker in terms of 
# swaps than plain BubbleSort, it is not really any better in terms
# of comparisons.   