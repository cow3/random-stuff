# Solutions to problems in Worksheet 8

# Question 1
#(a) O(x^4)
#(b) O(x^5)
#(c) O(2^x): even though x^100 starts out much bigger than
# 2^x, eventually 2^x is bigger. For example, let x = 2^{100}. 
# Then 2^x = 2^{2^100}, whilst x^{100} = 2^{200}.
#(d) O(x): log(x) grows more slowly than any power of x, so 
# whilst it takes a ver long time for x to be bigger, it eventually wins
#(e) O(3^x)
#(f) O(x^(1/100)): for the same reason as part (d)

# Question 2
# Let's try it!
L = [1, 3, 7, 9, 11, 13, 14]
a = 15
n = len(L)
i = 0
# while ((L[i] < a) and (i<n)):
#   i = i+1
#returns IndexError: list index out of range

# The problem is that python tries the left hand test before the
# one on the right, and so crashes when it tests whether L[n] < a,
# since there is no L[n]

# Question 3

# This function takes as input a list.
# it then sorts the list using the basic
# insertion sort method, and counts the number
# of comparisons it makes. It returns both the 
# sorted list and the number of comparisons 
# made, but only counting succesful comparisons between list 
# elements.

def InsertionSort(L):
    assert isinstance(L, list)
    n = len(L)
    comp_total = 0
    if n <= 1: # if L is very short there is nothing to do
                # This will catch lists of length 0 as well
        return L, comp_total
    done = [L[0]]
    for i in range(1,n):
        j  = 0
        while ((j < len(done)) and (L[i] > done[j])):
            j += 1
            comp_total += 1
        done = done[:j] + [L[i]] + done[j:]
    return done, comp_total
    
# Tests(a): running insertion sort on correctly sorted integers    
sort5, count5 = InsertionSort(range(1, 6))
# sort5 = [1, 2, 3, 4, 5]
# count5 = 10
       
sort10, count10 = InsertionSort(range(1, 11))
# sort10 = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
# count10 = 45

sort15, count15 = InsertionSort(range(1, 16))
# sort15 = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
# count15 = 105

# These are the same numbers as we saw for bubble sort:
# n(n-1)/2 on a list of length n

#Tests(b): running insertion sort on randomly shuffled integers  

# This is the function MyShuffle from Worksheet7

import random

def MyShuffle(n):
    result = []
    startList= range(1, n+1)
    for i in range(n):
        x = random.choice(startList)
        result.append(x)
        startList.remove(x)
    return result
 
# First we run on 20 random sequences of length 5    
results5 = [] 
for i in range(20): 
    results5.append(InsertionSort(MyShuffle(5))[1])
average5 = sum(results5)/20.0
# results5 =  [5, 7, 5, 3, 8, 2, 6, 6, 7, 8, 7, 3, 6, 5, 8, 3, 8, 7, 7, 5]
# average5 = 5.8
# Worst case 10, best case 3, mean 5.8

# Next we run on 20 random sequences of length 10
results10 = []
for i in range(20):  
    results10.append(InsertionSort(MyShuffle(10))[1])
average10 = sum(results10)/20.0  
#results10 = [19, 20, 20, 23, 26, 23, 37, 25, 12, 23, 16, 35, 26, 21, 25,
# 27, 19, 21, 20, 32]
#average10 = 23.5
# Worst case 37, best case 12, mean 23.5 

# Next we run on 20 random sequences of length 15
results15 = []
for i in range(20):
    results15.append(InsertionSort(MyShuffle(15))[1])
average15 = sum(results15)/20.0    
# results15 = [50, 66, 67, 60, 51, 57, 46, 62, 59, 46, 43, 61, 45, 37, 53, 71,
# 70, 41, 79, 51]
# average15 = 55.75

# Tests(c)
ones_list = []
for i in xrange(10):
    ones_list.append(1)
    
ones_count = InsertionSort(ones_list)[1]  
# ones_count is 0

# Conclusion: growth rate is growing roughly quadratically. The worst case is 
# an already-sorted list! As then we need to go all the way through the
# list to find the correct place to add each number

# Question 4

# The following function inserts a number a into
# the correct place in an already-sorted list
def Insert(a, L):
    assert isinstance(L, list)
    # First deal with the case L empty
    if len(L) == 0:
        return [a]
    #Now deal with the case where a goes
    #at the very beginning
    if (a <= L[0]):
        return [a] + L
    #now deal with the case where a goes
    #at the very end
    if (a >= L[-1]):
        return L + [a]
    #if reach here, a belongs somewhere in the middle
    #of the list
    left = 0
    right = len(L) - 1
    m = 1 #need to set m here so works right for
          #lists of length 2  
    while ((right - left) > 1):
        m = int((left + right)/2)
        if (L[m] < a):
            left = m
        else:
            right = m
    # code in worksheet wasn't quite correct, as
    # depended on whether m was equal to left
    # or right at end of while loop. This works better
    return L[:right] + [a] + L[right:]   

#The following function uses the bisection method
#to produce a sorted version of the list l
def BisectionSort(l):
    assert isinstance(l, list)
    n = len(l)
    done = []
    for i in range(n):
        done = Insert(l[i], done)
        #print done
    return done


# Tests(a): running bisection sort on correctly sorted integers    
bis_sort5 = BisectionSort(range(1, 6))
# bis_sort5 = [1, 2, 3, 4, 5]
       
bis_sort10 = BisectionSort(range(1, 11))
# sort10 = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

bis_sort15 = BisectionSort(range(1, 16))
# sort15 = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]

#Tests(b): running insertion sort on randomly shuffled integers  

# First we run on 20 random sequences of length 5    
for i in range(20): 
    assert range(1, 6) == BisectionSort(MyShuffle(5))
# all passed!     

# Next we run on 20 random sequences of length 10
for i in range(20):  
    assert range(1, 11) == BisectionSort(MyShuffle(10))
# all passed!

# Next we run on 20 random sequences of length 15
for i in range(20):
    assert range(1,16) == BisectionSort(MyShuffle(15))
# all passed! 
    
# Tests(c)
ones_list = []
for i in xrange(10):
    ones_list.append(1)
    
assert ones_list == BisectionSort(ones_list)  

    
# Question 5

# To count the number of comparisons it's best to modify the 
# insert function, as that is where the comparisons are taking
# place. InsertCount inserts an element a into an already sorted
# list, and counts the number of comparisons of list elements that
# it makes whilst doing so. We're only counting direct comparisons of
# list elements, not counts of the length of the list

def InsertCount(a, list):
    if len(list) == 0:
        return [a], 0
    if (a <= list[0]):
        return [a] + list, 1
    if (a >= list[-1]):
        return list + [a], 2
    left = 0
    right = len(list) - 1
    m = 1 
    comp_count = 2
    while ((right - left) > 1):
        m = int((left + right)/2)
        if (list[m] < a):
            left = m
        else:
            right = m
        comp_count += 1    
    return list[:right] + [a] + list[right:], comp_count  

# The function BisectionSortCount uses the bisection method version
# of insertion sort to sort a list, and returns both a sorted version
# of the list and the number of list comparisons that it has made

def BisectionSortCount(l):
    n = len(l)
    done = []
    comp_total = 0
    for i in range(n):
        done, count = InsertCount(l[i], done)
        comp_total += count
    return done, comp_total

count_data = []
for i in range(45):
    count_data.append(0)
for i in range(100):
    a = BisectionSortCount(MyShuffle(10))[1]
    count_data[a] +=1


import matplotlib.pyplot as plt

chart1 = plt.bar(range(45), count_data, 1, color = "blue")
plt.show()
 

# Average number of comparisons is now just under 30, which is
# actually slightly worse than it was before! Presumably the complexity win
# only happens for significantly longer lists.


# Question 6
  
import time
 
results = [] 
sizes = [100, 200, 400, 800, 1600, 3200, 6400]
for size in sizes: 
    result = 0                 
    for n in xrange(50):        
        # print "trial ", n, "size", size
        l = MyShuffle(size)                  
        start = time.time()           
        k = BisectionSort(l)
        end = time.time()
        result += ((end - start) * 1000)
    results.append(result/50)
   
# results is now  [0.318450927734375,
# 0.6764459609985352,
# 1.528477668762207,
# 4.1365814208984375,
# 12.288670539855957,
# 41.41063213348389,
# 165.54359436035156]  
   
# time definitely seems to grow more quickly than n log n: some time is 
# definitely being used in the python list assignment    