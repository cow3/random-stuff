# These are the solutions to the problems on Worksheet 9.

# Question 1

# Part (a)
# The following function implements Quicksort, as 
#described in the notes, for lists of integers.

def Quicksort(L):
    # Check we have the right input type
    assert isinstance(L, list)
    for x in L:
        assert isinstance(x, int)
    # list of length 0 or 1 is already sorted
    n = len(L)
    if n <= 1:
        return L
    # Split L into two lists, small and big
    pivot = L[0]
    small = []
    big = []
    for i in range(1,n):
        if L[i] <= pivot:
            small.append(L[i])
        else:
            big.append(L[i])
    #recursively call Quicksort on small and big
    small = Quicksort(small)
    big = Quicksort(big)
    return small + [pivot] + big

# Part (b)
# The worst case is a list that is either already sorted, 
# or where the list is in reverse order. 
# If the list is already sorted, then the pivot is the smallest
# element, so all elements go into the list big (and are all still
# sorted)
# Hence, when Quicksort is called recursively, each time the list is 
# only one smaller than it was before. 
# Similarly, if the list is in reverse order then the first element
# is the biggest, so the list small will contain all of L except for
# the pivot (and will still be in reverse order)

# Part (c)
#The worst case complexity of this version of quicksort is 
# O(n^2). This is because in the worst case, 
# for each recursive call either small or big is 
# everything in the list except for the pivot. Hence we 
# make (n-1) comparisons at depth 1, (n-2) at depth 2, and so on.

# Part (d)       
       
def MidQuicksort(L):
    #First check have right type of list
    assert isinstance(L, list)
    for x in L:
        assert isinstance(x, int)
    n = len(L)
    if n <= 1:
        return L
    middle = int(n/2)
    pivot = L[middle]
    small = []
    big = []
    for i in (range(0,middle) + range(middle+1, n)):
        if L[i] <= pivot:
            small.append(L[i])
        else:
            big.append(L[i])
    small = MidQuicksort(small)
    big = MidQuicksort(big)
    return small + [pivot] + big
#To make this version run badly, we could define a list where the 
#smallest element was the first pivot point, the second smallest 
#the first pivot point of the remaining elements, and so on.


# Question 2

# Part (a)
def Merge(S,T):
    # Check that we have two lists of integers
    assert isinstance(S, list)
    assert isinstance(T, list)
    for x in S:
        assert isinstance(x, int)
    for x in T:
        assert isinstance(x, int)
    U = []
    while (len(S) > 0) and (len(T) > 0):
        if S[0] < T[0]:
            U.append(S[0])
            S.remove(S[0])
        else:
            U.append(T[0])
            T.remove(T[0])
    if len(S) > 0:
        U = U+S
    if len(T) > 0:
        U = U+T
    return U        


# Part(b)

def Mergesort(L):
    #First check have right type of list
    assert isinstance(L, list)
    for x in L:
        assert isinstance(x, int)
    n = len(L)
    if n <= 1:
        return L
    half = int(n/2)
    S = L[:half]
    T = L[half:]
    S = Mergesort(S)
    T = Mergesort(T)
    return Merge(S, T)
    
# Part (c)
import time
import random 

# This is the shuffling function from Worksheet 7
def MyShuffle(n):
    result = []
    startList= range(1, n+1)
    for i in range(n):
        x = random.choice(startList)
        result.append(x)
        startList.remove(x)
    return result

L= MyShuffle(2**9)
start = time.time()           
k = Mergesort(L)
end = time.time()
result1 = ((end - start) * 1000)
# result1 is now 6.705045700073242

L = MyShuffle(2**10)
start = time.time()           
k = Mergesort(L)
end = time.time()
result2 = ((end - start) * 1000)
# result2 is now 12.186050415039062

L = MyShuffle(2**11)
start = time.time()           
k = Mergesort(L)
end = time.time()
result3 = ((end - start) * 1000)
# result3 is now 18.991947174072266

L = MyShuffle(2**12)
start = time.time()           
k = Mergesort(L)
end = time.time()
result4 = ((end - start) * 1000)
# result4 is now 27.66704559326172

# This seems to be pretty efficient - doubling the length is
# at worst doubling the time taken, and sometimes not even that much.

# Question 3

# First we make the cards, just as on worksheet 7
cards = []
for x in ["S", "H", "D", "C"]:
    for i in range(1,11) + ["J", "Q", "K"]:
        cards.append((x, i))
    
# We want to be able to compare the cards, so we will assign
# each one a numberical value from 0 to 51, based on its suit and
# value, so that the ace of spades is 0 through to the king of clubs
# at 51.
      
def suit_score(card):
    if card[0] == "S":
        return 0
    if card[0] == "H":
        return 13
    if card[0] == "D":
        return 26
    if card[0] == "C":
        return 39

def val_score(card):
    if card[1] in range(1,11):
        return card[1] 
    if card[1] == "J":
        return 11
    if card[1] == "Q":
        return 12
    if card[1] == "K":
        return 13

# This will now tell us whether one card belongs before the other in 
# the sorted list

def less_than(card1, card2):
    score1 = suit_score(card1) + val_score(card1)
    score2 = suit_score(card2) + val_score(card2)
    return score1 < score2
       
# The merge function doesn't change much from before

def Cardmerge(S,T):
    U = []
    while (len(S) > 0) and (len(T) > 0):
        if less_than(S[0], T[0]):
            U.append(S[0])
            S.remove(S[0])
        else:
            U.append(T[0])
            T.remove(T[0])
    if len(S) > 0:
        U = U+S
    if len(T) > 0:
        U = U+T
    return U        

# The main mergesort function changes very little indeed.
def CardMergesort(L):
    n = len(L)
    if n <= 1:
        return L
    half = int(n/2)
    S = L[:half]
    T = L[half:]
    S = CardMergesort(S)
    T = CardMergesort(T)
    return Cardmerge(S, T)
 
# Now for testing. 
# Here is the card shuffling function from the solutions to Worksheet 7
import copy

def permuteList(L):
    assert isinstance(L, list)
    res = []
    new_list = copy.copy(L)
    for i in xrange(len(L)):
        next_choice = random.choice(new_list)
        res.append(next_choice)
        new_list.remove(next_choice)
    return res


for i in range(50):
    shuffled = permuteList(cards)
    result = CardMergesort(shuffled)
    assert result == cards
    
# no assertions fail, so our code seems to be working ok.    


# Question 4

# Part (a). 
# Heap(k, L) takes a list L and an integer k, such that from 
# L[k+1] onwards the list is a heap. It makes L into a heap from 
# L[k] onwards
def Heap(k,L):
    assert isinstance(L, list)
    for x in L:
        assert isinstance(x, int)
    n = len(L)-1
    if 2*k+1 > n:  # nothing to do, this corresponds to a node of the 
                    # tree with no children
        return L
    if 2*k+2 > n:  # a node with one child
        if L[2*k+1] > L[k]: # child is bigger than parent, need to swap
            z = L[k]
            L[k] = L[2*k+1]
            L[2*k+1] = z
        return L
    if L[2*k+1] > L[2*k+2]: # find the larger of the two children
                            # as this is the one that will be promoted, if 
                            # any
        m = 2*k+1
    else:
        m = 2*k+2
    if L[k] > L[m]:  # L[k] is bigger than both of its children, so
                     # nothing to do
        return L
    else:
        z = L[k]     #swap parent and child 
        L[k] = L[m]
        L[m] = z
        return Heap(m, L) #recursive call: reheap the end part of the list


# Part (b). This takes as input a list, and turns it into a heap      
def FullHeap(L):
    n = int((len(L) - 1)/2)
    for i in range(n, -1, -1): # work through the list from the end to 
                               # the beginning
        L = Heap(i, L)
    return L        
    
# Part (c) The main heapsort algorithm
def Heapsort(L):
    assert isinstance(L, list)
    for x in L:
        assert isinstance(x, int)
    if len(L) <= 1:
        return L
    L = FullHeap(L)
    K = []
    while len(L) > 1:
        K = [L[0]] + K
        L[0] = L[-1]
        L = Heap(0, L[:-1])
    K = [L[0]] + K
    return K
   
# Now to test
for i in range(100):
    # test a sorted list of length i
    l = range(i)
    l1 = Heapsort(l)
    for k in range(i):
        assert l1[k] == k
    # and test 20 shuffled lists of length i
    for j in range(20):
        l = MyShuffle(i)
        l1 = Heapsort(l)
        for k in range(i):
            assert l1[k] == (k+1)

# All of them pass
            
# Question 5
 
# In place heap. It takes a list L and two integers 
# k and n. From n onwards, the list L contains the sorted
# largest members of L. Between k+1 and n-1 the list is a heap
# It reorders L such that the entries from L[n] onwards 
# are unchanged, but now between entry k and entry n-1 the list is 
# a heap. Notice that we never actually return anything other than 
# True - we are never assigning anything to be equal to a full 
# list, just modifying in place
def InPlaceHeap(k,L,n):
    if 2*k+1 > n-1:
        return True
    if 2*k+2 > n-1:
        if L[2*k+1] > L[k]:
            z = L[k]
            L[k] = L[2*k+1]
            L[2*k+1] = z
        return True
    if L[2*k+1] > L[2*k+2]:
        m = 2*k+1
    else:
        m = 2*k+2
    if L[k] > L[m]:
        return True
    else:
        z = L[k]
        L[k] = L[m]
        L[m] = z
        return InPlaceHeap(m, L, n)    
 
# Here is the replacement for the FullHeap function.
# Notice that we never assign anything to be equal to a 
# full list, all changes to the list happen in place
def InPlaceFullHeap(L):
    n = int((len(L) - 1)/2)
    for i in range(n, -1, -1): # work through the list from the end to 
                               # the beginning
        InPlaceHeap(i, L)
    return True       

  
# This is the implementation of heapsort in place. 

def InPlaceHeapsort(L):
    n = len(L)
    if n <= 1:
        return L
    FullHeap(L)
    #print "L = ", L
    for i in range(n):
        z = L[0]
        L[0] = L[n-i-1]
        L[n-i-1] = z
        #print "New L is ", L
        InPlaceHeap(0, L, n-i-1) 
        #print "i = ", i, "l = ", L
    return L
        
    
# Now to test
for i in range(100):
    # test a sorted list of length i
    l = range(i)
    InPlaceHeapsort(l)
    for k in range(i):
        assert l[k] == k
    # and test 20 shuffled lists of length i
    for j in range(20):
        l = MyShuffle(i)
        InPlaceHeapsort(l)
        for k in range(i):
            assert l[k] == (k+1)
 
# All passed! 